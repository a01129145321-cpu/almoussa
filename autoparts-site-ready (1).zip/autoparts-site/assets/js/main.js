(function () {
  'use strict';

  // -------- قائمة الموبايل --------
  var toggle = document.getElementById('mobileToggle');
  var nav = document.getElementById('mainNav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      nav.classList.toggle('open');
    });
  }

  // -------- معرض صور المنتج --------
  document.querySelectorAll('[data-gallery-thumb]').forEach(function (thumb) {
    thumb.addEventListener('click', function () {
      var mainImg = document.querySelector('[data-gallery-main]');
      if (!mainImg) return;
      document.querySelectorAll('[data-gallery-thumb]').forEach(function (t) { t.classList.remove('active'); });
      thumb.classList.add('active');
      mainImg.src = thumb.getAttribute('data-full') || thumb.src;
    });
  });

  // -------- عناصر التحكم بالكمية (+ / -) --------
  document.querySelectorAll('.qty-control').forEach(function (control) {
    var input = control.querySelector('input');
    var minus = control.querySelector('[data-qty-minus]');
    var plus = control.querySelector('[data-qty-plus]');
    if (!input) return;

    function clampValue() {
      var v = parseInt(input.value, 10);
      if (isNaN(v) || v < 1) v = 1;
      input.value = v;
      return v;
    }

    if (minus) minus.addEventListener('click', function () {
      input.value = clampValue() - 1;
      clampValue();
      input.dispatchEvent(new Event('change'));
    });
    if (plus) plus.addEventListener('click', function () {
      input.value = clampValue() + 1;
      clampValue();
      input.dispatchEvent(new Event('change'));
    });
    input.addEventListener('change', clampValue);
  });

  // -------- إضافة إلى السلة عبر AJAX --------
  var cartCountEls = document.querySelectorAll('.cart-count');

  function updateCartCount(count) {
    cartCountEls.forEach(function (el) { el.textContent = count; });
  }

  function postForm(url, data) {
    return fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest' },
      body: new URLSearchParams(data).toString(),
    }).then(function (r) { return r.json(); });
  }

  document.querySelectorAll('[data-add-cart]').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      var productId = btn.getAttribute('data-product-id');
      var csrf = document.querySelector('meta[name="csrf-token"]');
      var qtyEl = document.querySelector('[data-qty-for="' + productId + '"]');
      var qty = qtyEl ? qtyEl.value : 1;

      btn.disabled = true;
      postForm(window.APP_BASE_URL + 'cart_action.php', {
        action: 'add',
        product_id: productId,
        quantity: qty,
        csrf_token: csrf ? csrf.content : ''
      }).then(function (res) {
        btn.disabled = false;
        if (res && res.success) {
          updateCartCount(res.cart_count);
          btn.classList.add('btn-added');
          var original = btn.innerHTML;
          btn.innerHTML = '✓';
          setTimeout(function () { btn.innerHTML = original; }, 1200);
        } else if (res && res.message) {
          alert(res.message);
        }
      }).catch(function () {
        btn.disabled = false;
      });
    });
  });

  // -------- إظهار/إخفاء بيانات التحويل البنكي حسب طريقة الدفع المختارة --------
  var bankBox = document.getElementById('bankDetailsBox');
  var paymentRadios = document.querySelectorAll('input[name="payment_method"]');
  if (bankBox && paymentRadios.length) {
    function syncBankBox() {
      var selected = document.querySelector('input[name="payment_method"]:checked');
      bankBox.style.display = (selected && selected.value === 'bank_transfer') ? '' : 'none';
    }
    paymentRadios.forEach(function (r) { r.addEventListener('change', syncBankBox); });
    syncBankBox();
  }

  // -------- تحديث/حذف عناصر صفحة السلة عبر AJAX مع سقوط احتياطي للنموذج العادي --------
  document.querySelectorAll('[data-cart-remove]').forEach(function (link) {
    link.addEventListener('click', function (e) {
      var row = link.closest('tr');
      if (row) {
        row.style.opacity = '.4';
      }
      // النموذج العادي (POST) يكفي للعمل حتى دون جافاسكربت
    });
  });
})();
