-- للاستخدام فقط إذا كنت قد استوردت قاعدة البيانات قبل إضافة طريقة الدفع:
ALTER TABLE orders
    ADD COLUMN payment_method ENUM('cod','bank_transfer') NOT NULL DEFAULT 'cod' AFTER total_amount,
    ADD COLUMN payment_status ENUM('pending','paid') NOT NULL DEFAULT 'pending' AFTER payment_method;
