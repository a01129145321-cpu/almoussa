-- ============================================================
-- قاعدة بيانات موقع قطع غيار السيارات
-- متوافقة مع MySQL / MariaDB على Hostinger
-- ============================================================
-- طريقة الاستخدام:
-- 1) من لوحة تحكم Hostinger (hPanel) أنشئ قاعدة بيانات MySQL جديدة.
-- 2) افتح phpMyAdmin الخاص بقاعدة البيانات.
-- 3) بوّاب "Import" وارفع هذا الملف كاملاً، أو انسخ محتواه إلى تبويب SQL ونفّذه.
-- ============================================================

SET NAMES utf8mb4;
SET time_zone = '+03:00';

-- ------------------------------------------------------------
-- جدول مستخدمي لوحة التحكم (الإدارة)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admin_users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) DEFAULT NULL,
    last_login DATETIME DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ملاحظة أمنية مهمة:
-- لا يحتوي هذا الملف على أي حساب إداري جاهز بكلمة مرور معروفة.
-- عند أول زيارة لمسار admin/setup.php سيُطلب منك إنشاء أول حساب مدير
-- بنفسك، ليتم تشفير كلمة المرور مباشرة بواسطة PHP على سيرفرك.
-- هذا أكثر أمانًا من نشر كلمة مرور افتراضية معروفة للجميع.

-- ------------------------------------------------------------
-- جدول محاولات الدخول الفاشلة (حماية لوحة التحكم من التخمين)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS login_attempts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ip VARCHAR(45) NOT NULL,
    attempted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_ip_time (ip, attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- جدول الأقسام الرئيسية لقطع الغيار
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS categories (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(120) NOT NULL UNIQUE,
    description VARCHAR(255) DEFAULT NULL,
    icon VARCHAR(50) DEFAULT NULL,
    sort_order INT UNSIGNED NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- جدول الشركات المصنّعة
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS manufacturers (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- جدول المنتجات (قطع الغيار)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS products (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    slug VARCHAR(220) NOT NULL UNIQUE,
    part_number VARCHAR(100) NOT NULL,
    category_id INT UNSIGNED DEFAULT NULL,
    manufacturer_id INT UNSIGNED DEFAULT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    old_price DECIMAL(10,2) DEFAULT NULL,
    description TEXT,
    compatible_cars TEXT,
    availability ENUM('available','out_of_stock','on_order') NOT NULL DEFAULT 'available',
    stock_quantity INT UNSIGNED NOT NULL DEFAULT 0,
    main_image VARCHAR(255) DEFAULT NULL,
    is_featured TINYINT(1) NOT NULL DEFAULT 0,
    views INT UNSIGNED NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_category (category_id),
    KEY idx_manufacturer (manufacturer_id),
    KEY idx_part_number (part_number),
    FULLTEXT KEY ft_search (name, part_number, description),
    CONSTRAINT fk_products_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
    CONSTRAINT fk_products_manufacturer FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- جدول صور المنتج (صور إضافية متعددة لكل منتج)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS product_images (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    product_id INT UNSIGNED NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    sort_order INT UNSIGNED NOT NULL DEFAULT 0,
    CONSTRAINT fk_images_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- جدول الطلبات
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS orders (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(20) NOT NULL UNIQUE,
    customer_name VARCHAR(150) NOT NULL,
    phone VARCHAR(30) NOT NULL,
    whatsapp VARCHAR(30) DEFAULT NULL,
    email VARCHAR(150) DEFAULT NULL,
    city VARCHAR(100) DEFAULT NULL,
    address VARCHAR(255) DEFAULT NULL,
    notes TEXT,
    subtotal_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    shipping_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    vat_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    total_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    payment_method ENUM('cod','bank_transfer') NOT NULL DEFAULT 'cod',
    payment_status ENUM('pending','paid') NOT NULL DEFAULT 'pending',
    status ENUM('new','processing','confirmed','shipped','completed','cancelled') NOT NULL DEFAULT 'new',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- جدول عناصر الطلب
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS order_items (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id INT UNSIGNED NOT NULL,
    product_id INT UNSIGNED DEFAULT NULL,
    product_name VARCHAR(200) NOT NULL,
    part_number VARCHAR(100) DEFAULT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    quantity INT UNSIGNED NOT NULL DEFAULT 1,
    subtotal DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    CONSTRAINT fk_items_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_items_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- جدول رسائل نموذج التواصل
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contact_messages (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    phone VARCHAR(30) DEFAULT NULL,
    email VARCHAR(150) DEFAULT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- الأقسام والشركات المصنعة (تويوتا ولكزس فقط)
-- ============================================================
INSERT INTO categories (id, name, slug, description, icon, sort_order) VALUES
(1, 'محرك وملحقاته', 'engines', '', 'engine', 1),
(2, 'فرامل', 'brakes', '', 'brake', 2),
(3, 'كهرباء وحساسات', 'electrical', '', 'battery', 3),
(4, 'فلاتر وزيوت', 'filters-oils', '', 'filter', 4),
(5, 'تعليق ومقصات', 'suspension', '', 'suspension', 5),
(6, 'تبريد وتكييف', 'cooling-ac', '', 'badge', 6),
(7, 'ناقل الحركة والدفرنس', 'transmission', '', 'wrench', 7),
(8, 'هيكل وزينة وإكسسوارات', 'body', '', 'truck', 8),
(9, 'قطع متنوعة', 'misc', '', 'box', 9);

INSERT INTO manufacturers (id, name) VALUES
(1, 'تويوتا'),
(2, 'لكزس');

-- ============================================================
-- الخطوة التالية: استورد ملف products_data.sql لإضافة المنتجات
-- (5136 قطعة غيار حقيقية بأسعارها وأرقامها وكمياتها).
-- ============================================================
