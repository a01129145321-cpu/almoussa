-- للاستخدام فقط إذا كنت قد استوردت قاعدة البيانات قبل إضافة رسوم الشحن:
ALTER TABLE orders
    ADD COLUMN shipping_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER subtotal_amount;
