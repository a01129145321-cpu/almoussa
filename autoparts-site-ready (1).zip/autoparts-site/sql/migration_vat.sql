-- للاستخدام فقط إذا كنت قد استوردت قاعدة البيانات قبل إضافة الضريبة:
ALTER TABLE orders
    ADD COLUMN subtotal_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER notes,
    ADD COLUMN vat_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER subtotal_amount;
-- الطلبات القديمة (إن وُجدت) تُعتبر إجماليها قبل الضريبة:
UPDATE orders SET subtotal_amount = total_amount WHERE subtotal_amount = 0;
