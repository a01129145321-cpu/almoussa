<?php
/**
 * بطاقة منتج قابلة لإعادة الاستخدام
 * تتوقع أن يكون المتغير $p يحتوي على بيانات المنتج (صف من جدول products)
 */
if (!isset($p)) {
    return;
}
$productUrl = base_url('product.php?id=' . (int)$p['id']);
?>
<div class="product-card">
    <a href="<?= $productUrl ?>" class="product-thumb">
        <span class="badge <?= availability_class($p['availability']) ?>"><?= availability_label($p['availability']) ?></span>
        <img src="<?= clean(product_thumb_url($p)) ?>" alt="<?= clean($p['name']) ?>" loading="lazy">
    </a>
    <div class="product-body">
        <?php if (!empty($p['category_name'])): ?>
            <span class="product-cat"><?= clean($p['category_name']) ?></span>
        <?php endif; ?>
        <h3 class="product-name"><a href="<?= $productUrl ?>"><?= clean($p['name']) ?></a></h3>
        <span class="part-tag"><?= icon('badge', 'icon-sm') ?> <?= clean($p['part_number']) ?></span>
        <?php if ($stock = stock_display((int)$p['stock_quantity'], $p['availability'])): ?>
            <span class="stock-note <?= $stock['low'] ? 'stock-note-low' : '' ?>"><?= clean($stock['text']) ?></span>
        <?php endif; ?>
        <div class="product-footer">
            <div>
                <?php if (!empty($p['old_price']) && $p['old_price'] > $p['price']): ?>
                    <span class="price-old"><?= format_price((float)$p['old_price']) ?></span>
                <?php endif; ?>
                <span class="price"><?= format_price((float)$p['price']) ?></span>
            </div>
            <button type="button" class="add-cart-btn" data-add-cart data-product-id="<?= (int)$p['id'] ?>"
                    <?= $p['availability'] === 'out_of_stock' ? 'disabled title="غير متوفر حاليًا"' : 'title="أضف إلى الطلب"' ?>>
                <?= icon('cart', 'icon-sm') ?>
            </button>
        </div>
    </div>
</div>
