<?php
/**
 * الاتصال بقاعدة البيانات باستخدام PDO
 * يستخدم Prepared Statements في كل مكان لمنع SQL Injection
 */

require_once __DIR__ . '/../config/config.php';

function get_db(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            if (DEBUG_MODE) {
                die('خطأ في الاتصال بقاعدة البيانات: ' . htmlspecialchars($e->getMessage()));
            }
            die('عذرًا، حدث خطأ فني مؤقت. الرجاء المحاولة لاحقًا.');
        }
    }

    return $pdo;
}
