<?php
/**
 * الهيدر المشترك لكل صفحات الموقع (غير لوحة التحكم)
 * الصفحة التي تستدعي هذا الملف يجب أن تُعرّف مسبقًا:
 * $page_title, $page_description (اختياري: $page_canonical, $schema_json)
 */
require_once __DIR__ . '/functions.php';
start_app_session();

$page_title       = $page_title ?? SITE_NAME;
$page_description = $page_description ?? SITE_SLOGAN;
$active_page      = current_page();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= clean($page_title) ?> | <?= clean(SITE_NAME) ?></title>
<meta name="description" content="<?= clean($page_description) ?>">
<link rel="canonical" href="<?= clean($page_canonical ?? rtrim(SITE_URL, '/') . '/' . ltrim($_SERVER['REQUEST_URI'] ?? '', '/')) ?>">
<meta property="og:title" content="<?= clean($page_title) ?>">
<meta property="og:description" content="<?= clean($page_description) ?>">
<meta property="og:type" content="website">
<meta property="og:site_name" content="<?= clean(SITE_NAME) ?>">
<meta property="og:image" content="<?= clean(abs_url('assets/images/logo/favicon-192.png')) ?>">
<meta name="robots" content="index, follow">
<meta name="csrf-token" content="<?= csrf_token() ?>">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600;700;800&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
<link rel="icon" href="<?= base_url('assets/images/logo/favicon-32.png') ?>" sizes="32x32">
<link rel="icon" href="<?= base_url('assets/images/logo/favicon-192.png') ?>" sizes="192x192">
<link rel="apple-touch-icon" href="<?= base_url('assets/images/logo/favicon-192.png') ?>">

<?php if (!empty($schema_json)): ?>
<script type="application/ld+json"><?= $schema_json ?></script>
<?php endif; ?>
</head>
<body>

<header class="site-header">
    <div class="header-top">
        <div class="container">
            <div class="header-top-links">
                <span><?= icon('clock', 'icon-sm') ?> <?= clean(WORKING_HOURS) ?></span>
                <a href="<?= clean(GOOGLE_MAPS_LINK) ?>" target="_blank" rel="noopener"><?= icon('location', 'icon-sm') ?> <?= clean(COMPANY_ADDRESS) ?></a>
            </div>
            <div class="header-top-links">
                <a href="tel:<?= clean(COMPANY_PHONE) ?>"><?= icon('phone', 'icon-sm') ?> <?= clean(COMPANY_PHONE) ?></a>
                <a href="mailto:<?= clean(COMPANY_EMAIL) ?>"><?= icon('email', 'icon-sm') ?> <?= clean(COMPANY_EMAIL) ?></a>
            </div>
        </div>
    </div>

    <div class="container header-main">
        <a href="<?= base_url('index.php') ?>" class="brand">
            <img src="<?= logo_url() ?>" alt="<?= clean(SITE_NAME) ?>" class="brand-mark brand-mark-img">
            <span class="brand-text">
                <span class="brand-name"><?= clean(SITE_NAME) ?></span>
                <span class="brand-slogan"><?= clean(SITE_SLOGAN) ?></span>
            </span>
        </a>

        <nav class="main-nav" id="mainNav">
            <a href="<?= base_url('index.php') ?>" class="<?= $active_page === 'index' ? 'active' : '' ?>">الرئيسية</a>
            <a href="<?= base_url('products.php') ?>" class="<?= $active_page === 'products' ? 'active' : '' ?>">قطع الغيار</a>
            <a href="<?= base_url('about.php') ?>" class="<?= $active_page === 'about' ? 'active' : '' ?>">من نحن</a>
            <a href="<?= base_url('contact.php') ?>" class="<?= $active_page === 'contact' ? 'active' : '' ?>">تواصل معنا</a>
        </nav>

        <div class="header-actions">
            <form action="<?= base_url('products.php') ?>" method="get" class="header-search btn-text" role="search">
                <input type="search" name="q" placeholder="ابحث بالاسم أو رقم القطعة" aria-label="بحث" value="<?= clean($_GET['q'] ?? '') ?>">
                <button type="submit" class="icon-btn" title="بحث" aria-label="بحث"><?= icon('search') ?></button>
            </form>
            <a href="<?= base_url('cart.php') ?>" class="icon-btn" title="سلة الطلب">
                <?= icon('cart') ?>
                <span class="cart-count"><?= (int)cart_count() ?></span>
            </a>
            <button class="mobile-toggle" id="mobileToggle" aria-label="القائمة">
                <?= icon('menu') ?>
            </button>
        </div>
    </div>
</header>

<a href="<?= whatsapp_link('مرحبًا، أرغب بالاستفسار عن قطع غيار') ?>" class="whatsapp-float" target="_blank" rel="noopener" title="تواصل عبر واتساب">
    <?= icon('whatsapp', 'icon-lg') ?>
</a>

<?php if ($msg = flash_get('success')): ?>
    <div class="container" style="padding-top:20px">
        <div class="alert alert-success"><?= clean($msg) ?></div>
    </div>
<?php endif; ?>
<?php if ($msg = flash_get('error')): ?>
    <div class="container" style="padding-top:20px">
        <div class="alert alert-danger"><?= clean($msg) ?></div>
    </div>
<?php endif; ?>
