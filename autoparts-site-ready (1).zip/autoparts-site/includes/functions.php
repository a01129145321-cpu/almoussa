<?php
/**
 * دوال مساعدة عامة تُستخدم في كل صفحات الموقع
 */

require_once __DIR__ . '/db.php';

// في وضع الإنتاج: أي خطأ غير متوقع يُسجَّل في سجل الاستضافة ويرى الزائر صفحة اعتذار بدل شاشة بيضاء
if (!DEBUG_MODE) {
    set_exception_handler(function (Throwable $e) {
        error_log('Uncaught: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: text/html; charset=utf-8');
        }
        echo '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>خطأ مؤقت</title></head>'
           . '<body style="font-family:Tahoma,Arial,sans-serif;text-align:center;padding:60px 20px"><h1>عذرًا، حدث خطأ مؤقت</h1>'
           . '<p>الرجاء المحاولة مرة أخرى بعد قليل، أو التواصل معنا عبر الهاتف أو واتساب.</p></body></html>';
        exit;
    });
}

// ============================================================
// الجلسات
// ============================================================
function start_app_session(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_name(SESSION_NAME);
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'secure'   => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }
}

// ============================================================
// الأمان: تنظيف المدخلات ومنع XSS
// ============================================================
function clean(?string $value): string
{
    return htmlspecialchars(trim($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function sanitize_text(?string $value): string
{
    return trim(strip_tags($value ?? ''));
}

// ============================================================
// الأمان: CSRF Token لحماية النماذج
// ============================================================
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . csrf_token() . '">';
}

/** حقل مخفي فخّ للروبوتات: المستخدم الحقيقي لا يراه فيبقى فارغًا */
function honeypot_field(): string
{
    return '<div style="position:absolute;left:-9999px;top:-9999px" aria-hidden="true"><label>الموقع الإلكتروني<input type="text" name="website" value="" tabindex="-1" autocomplete="off"></label></div>';
}

function honeypot_triggered(): bool
{
    return !empty($_POST['website']);
}

function verify_csrf(): bool
{
    $token = $_POST['csrf_token'] ?? '';
    return !empty($token) && !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function require_valid_csrf(): void
{
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !verify_csrf()) {
        http_response_code(400);
        die('طلب غير صالح (CSRF). الرجاء إعادة تحميل الصفحة والمحاولة مرة أخرى.');
    }
}

// ============================================================
// روابط وتنسيق
// ============================================================
/**
 * مسار جذر الموقع على السيرفر (فارغ إذا كان الموقع في جذر الدومين، أو مثل /sub إن كان داخل مجلد فرعي).
 * تُبنى كل روابط التنقل نسبةً إليه، فتعمل الصفحات والسلة على أي دومين (مع www وبدونه، ودومين مؤقت أثناء التجربة)
 * دون الاعتماد على SITE_URL.
 */
function base_path(): string
{
    static $path = null;
    if ($path === null) {
        $path = '';
        $docRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '');
        $siteDir = realpath(__DIR__ . '/..');
        if ($docRoot && $siteDir && strpos($siteDir, $docRoot) === 0) {
            $path = rtrim(str_replace('\\', '/', substr($siteDir, strlen($docRoot))), '/');
        }
    }
    return $path;
}

/** رابط داخلي نسبي لجذر الموقع، مثال: base_url('products.php') => /products.php */
function base_url(string $path = ''): string
{
    return base_path() . '/' . ltrim($path, '/');
}

/** رابط مطلق كامل (للـ canonical وخريطة الموقع والبريد) مبني على SITE_URL */
function abs_url(string $path = ''): string
{
    return rtrim(SITE_URL, '/') . base_url($path);
}

/**
 * كود تضمين الخريطة: يستخدم GOOGLE_MAPS_EMBED إن كان مضبوطًا يدويًا (أدق)،
 * وإلا يبني iframe تلقائيًا من عنوان الشركة (بدون أي مفتاح API).
 */
function google_maps_embed_html(): string
{
    if (!empty(GOOGLE_MAPS_EMBED)) {
        return GOOGLE_MAPS_EMBED;
    }
    $src = 'https://www.google.com/maps?q=' . rawurlencode(COMPANY_ADDRESS) . '&output=embed';
    return '<iframe src="' . $src . '" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>';
}

/** رابط شعار الشركة (استبدل الملف بنفس الاسم لتغيير الشعار لاحقًا) */
function logo_url(): string
{
    return base_url('assets/images/logo/logo.png');
}

function format_price(float $price): string
{
    return number_format($price, 2) . ' ' . CURRENCY;
}

function slugify(string $text): string
{
    // يدعم تحويل النصوص العربية والإنجليزية إلى رابط نظيف
    $text = trim($text);
    $text = preg_replace('/[\s]+/u', '-', $text);
    $text = preg_replace('/[^\p{L}\p{N}\-]+/u', '', $text);
    $text = preg_replace('/-+/', '-', $text);
    return trim($text, '-') ?: 'item-' . substr(bin2hex(random_bytes(4)), 0, 8);
}

function availability_label(string $status): string
{
    return match ($status) {
        'available'    => 'متوفر',
        'out_of_stock' => 'غير متوفر حاليًا',
        'on_order'     => 'يتوفر بالطلب',
        default        => 'غير محدد',
    };
}

/**
 * نص رصيد المخزون الظاهر للعميل بجانب كل منتج.
 * يعيد مصفوفة ['text' => ..., 'low' => bool] أو null إن لم يكن هناك ما يُعرض.
 */
function stock_display(int $stockQuantity, string $availability): ?array
{
    if ($availability === 'on_order') {
        return ['text' => 'يتوفر خلال أيام عند الطلب', 'low' => false];
    }
    if ($availability !== 'available' || $stockQuantity <= 0) {
        return null;
    }
    if ($stockQuantity <= LOW_STOCK_THRESHOLD) {
        return ['text' => 'كمية محدودة — متبقي ' . $stockQuantity . ' فقط', 'low' => true];
    }
    return ['text' => 'متوفر بالمخزون: ' . $stockQuantity . ' قطعة', 'low' => false];
}

function availability_class(string $status): string
{
    return match ($status) {
        'available'    => 'badge-success',
        'out_of_stock' => 'badge-danger',
        'on_order'     => 'badge-warning',
        default        => 'badge-muted',
    };
}

/**
 * يضبط حالة التوفر تلقائيًا حسب الكمية لمنع تعارض الكمية مع الحالة:
 * - كمية صفر: تصبح "غير متوفر" إلا إذا اختار الأدمن صراحة "يتوفر بالطلب".
 * - كمية أكبر من صفر: تصبح "متوفر" دائمًا (حتى لو كانت محفوظة سابقًا كـ"غير متوفر").
 */
function resolve_availability(int $stockQuantity, string $requestedAvailability): string
{
    if ($stockQuantity > 0) {
        return 'available';
    }
    return $requestedAvailability === 'on_order' ? 'on_order' : 'out_of_stock';
}

/**
 * يزيد أو ينقص كمية مخزون منتج (delta موجب = إضافة، سالب = خصم)، ولا يسمح بالنزول تحت صفر،
 * ويصحّح حالة التوفر تلقائيًا بعد التعديل. تُستخدم عند إنشاء الطلب (خصم) وعند إلغائه (إعادة).
 */
function apply_stock_delta(PDO $pdo, int $productId, int $delta): void
{
    if ($delta === 0) {
        return;
    }
    $pdo->prepare('UPDATE products SET stock_quantity = GREATEST(0, CAST(stock_quantity AS SIGNED) + CAST(:d AS SIGNED)) WHERE id = :id')
        ->execute([':d' => (int)$delta, ':id' => $productId]);
    $pdo->prepare("
        UPDATE products SET availability = CASE
            WHEN stock_quantity = 0 AND availability = 'available' THEN 'out_of_stock'
            WHEN stock_quantity > 0 AND availability = 'out_of_stock' THEN 'available'
            ELSE availability
        END WHERE id = :id
    ")->execute([':id' => $productId]);
}

/** قائمة الحسابات البنكية الصالحة (bank, name, iban) */
function bank_accounts(): array
{
    $list = [];
    foreach ((defined('BANK_ACCOUNTS') ? BANK_ACCOUNTS : []) as $acc) {
        if (!empty($acc['iban']) && !empty($acc['name'])) {
            $list[] = ['bank' => (string)($acc['bank'] ?? ''), 'name' => (string)$acc['name'], 'iban' => (string)$acc['iban']];
        }
    }
    if (!$list && BANK_IBAN !== '' && BANK_ACCOUNT_NAME !== '') {
        $list[] = ['bank' => BANK_NAME, 'name' => BANK_ACCOUNT_NAME, 'iban' => BANK_IBAN];
    }
    return $list;
}

function bank_transfer_configured(): bool
{
    return !empty(bank_accounts());
}

/** HTML قائمة الحسابات البنكية (يُستخدم في السلة وصفحة تأكيد الطلب) */
function bank_accounts_html(): string
{
    $html = '';
    foreach (bank_accounts() as $acc) {
        $html .= '<div class="bank-account">'
              . '<div class="spec-table-mini">'
              . ($acc['bank'] !== '' ? '<div><span>البنك</span><b>' . clean($acc['bank']) . '</b></div>' : '')
              . '<div><span>اسم الحساب</span><b>' . clean($acc['name']) . '</b></div>'
              . '<div><span>الآيبان</span><b dir="ltr" class="iban">' . clean($acc['iban']) . '</b></div>'
              . '</div></div>';
    }
    return $html;
}

function payment_method_label(string $method): string
{
    return $method === 'bank_transfer' ? 'تحويل بنكي' : 'الدفع عند الاستلام';
}

function payment_status_label(string $status): string
{
    return $status === 'paid' ? 'تم الدفع' : 'بانتظار الدفع';
}

function order_status_label(string $status): string
{
    return match ($status) {
        'new'        => 'جديد',
        'processing' => 'قيد المعالجة',
        'confirmed'  => 'مؤكد',
        'shipped'    => 'تم الشحن',
        'completed'  => 'مكتمل',
        'cancelled'  => 'ملغي',
        default      => $status,
    };
}

// ============================================================
// روابط واتساب
// ============================================================
function whatsapp_link(string $message = ''): string
{
    $number = preg_replace('/\D+/', '', COMPANY_WHATSAPP);
    $url = 'https://wa.me/' . $number;
    if ($message !== '') {
        $url .= '?text=' . rawurlencode($message);
    }
    return $url;
}

// ============================================================
// الصور والرفع
// ============================================================
function product_image_url(?string $path): string
{
    if (empty($path)) {
        return base_url('assets/images/samples/placeholder.svg');
    }
    // إذا كان المسار كاملاً (رابط خارجي) أعده كما هو
    if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://')) {
        return $path;
    }
    return base_url($path);
}

/**
 * البحث عن صورة للقطعة بحسب رقمها داخل uploads/parts/
 * مثال: uploads/parts/90919-02154.jpg  (الاسم = رقم القطعة تمامًا)
 */
function find_part_image(?string $partNumber): ?string
{
    if (empty($partNumber) || !preg_match('/^[A-Za-z0-9\-_.]+$/', $partNumber)) {
        return null;
    }
    foreach (['jpg', 'jpeg', 'png', 'webp'] as $ext) {
        $rel = 'uploads/parts/' . $partNumber . '.' . $ext;
        if (is_file(__DIR__ . '/../' . $rel)) {
            return $rel;
        }
    }
    return null;
}

/** رابط صورة المنتج: الصورة المرفوعة، ثم صورة رقم القطعة، ثم الصورة البديلة */
function product_thumb_url(array $product): string
{
    $path = !empty($product['main_image']) ? $product['main_image'] : find_part_image($product['part_number'] ?? '');
    return product_image_url($path);
}

/**
 * يتحقق من صحة صورة مرفوعة ويرفعها بأمان إلى مجلد uploads/products
 * يعيد المسار النسبي للملف عند النجاح أو null عند الفشل
 */
function handle_product_image_upload(array $file): ?array
{
    if (empty($file['name']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['error' => 'فشل رفع الصورة (رمز الخطأ: ' . $file['error'] . ')'];
    }

    $maxBytes = MAX_UPLOAD_SIZE_MB * 1024 * 1024;
    if ($file['size'] > $maxBytes) {
        return ['error' => 'حجم الصورة أكبر من الحد المسموح (' . MAX_UPLOAD_SIZE_MB . ' ميجابايت)'];
    }

    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
    ];

    // التحقق الفعلي من نوع الملف عبر finfo (وليس الاعتماد على الامتداد فقط)
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);

    if (!isset($allowed[$mime])) {
        return ['error' => 'صيغة الصورة غير مدعومة. الصيغ المسموحة: JPG, PNG, WEBP فقط'];
    }

    // التأكد أن الملف صورة حقيقية فعلاً
    if (@getimagesize($file['tmp_name']) === false) {
        return ['error' => 'الملف المرفوع ليس صورة صالحة'];
    }

    $ext = $allowed[$mime];
    $filename = 'p_' . date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
    $destDir = __DIR__ . '/../uploads/products/';
    $destPath = $destDir . $filename;

    if (!is_dir($destDir)) {
        mkdir($destDir, 0755, true);
    }

    if (!move_uploaded_file($file['tmp_name'], $destPath)) {
        return ['error' => 'تعذر حفظ الصورة على السيرفر'];
    }

    return ['path' => 'uploads/products/' . $filename];
}

// ============================================================
// السلة (تُخزن في الجلسة فقط، لا تحتاج تسجيل دخول العميل)
// ============================================================
function &cart_items(): array
{
    if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    return $_SESSION['cart'];
}

function cart_add(int $productId, int $qty = 1): void
{
    $cart = &cart_items();
    if (isset($cart[$productId])) {
        $cart[$productId] += $qty;
    } else {
        $cart[$productId] = $qty;
    }
    if ($cart[$productId] < 1) {
        unset($cart[$productId]);
    }
}

function cart_update(int $productId, int $qty): void
{
    $cart = &cart_items();
    if ($qty <= 0) {
        unset($cart[$productId]);
    } else {
        $cart[$productId] = $qty;
    }
}

function cart_remove(int $productId): void
{
    $cart = &cart_items();
    unset($cart[$productId]);
}

function cart_clear(): void
{
    $_SESSION['cart'] = [];
}

function cart_count(): int
{
    $cart = cart_items();
    return array_sum($cart);
}

/** رسوم الشحن: مجاني إذا تجاوز إجمالي القطع الحد المحدد، وإلا الرسوم الثابتة */
function shipping_for(float $subtotal): float
{
    if ($subtotal <= 0) {
        return 0.0;
    }
    return $subtotal > FREE_SHIPPING_THRESHOLD ? 0.0 : (float)SHIPPING_FEE;
}

/**
 * يجلب تفاصيل منتجات السلة من قاعدة البيانات مع الكميات والإجمالي
 */
function cart_details(): array
{
    $cart = cart_items();
    if (empty($cart)) {
        return ['items' => [], 'subtotal' => 0.0, 'shipping' => 0.0, 'vat' => 0.0, 'total' => 0.0];
    }

    $ids = array_keys($cart);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $pdo = get_db();
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
    $stmt->execute($ids);
    $products = $stmt->fetchAll();

    $items = [];
    $total = 0.0;

    foreach ($products as $product) {
        $qty = (int)($cart[$product['id']] ?? 0);
        if ($qty <= 0) {
            continue;
        }
        $subtotal = $qty * (float)$product['price'];
        $total += $subtotal;
        $items[] = [
            'product'  => $product,
            'quantity' => $qty,
            'subtotal' => $subtotal,
        ];
    }

    $shipping = shipping_for($total);
    $vat = round(($total + (VAT_ON_SHIPPING ? $shipping : 0)) * VAT_RATE, 2);
    return ['items' => $items, 'subtotal' => $total, 'shipping' => $shipping, 'vat' => $vat, 'total' => round($total + $shipping + $vat, 2)];
}


// ============================================================
// البحث في المنتجات (يُستخدم في الموقع ولوحة التحكم)
// ============================================================
/**
 * يبني شرط بحث ذكي: كل كلمة في عبارة البحث يجب أن توجد في الاسم أو رقم القطعة (بشرطة أو بدونها).
 * مثال: "كويل كامري" يطابق "كويل كامري 2018" حتى لو تباعدت الكلمات. يملأ $params ويعيد جزء SQL.
 */
function product_search_sql(string $search, array &$params, string $alias = 'p'): string
{
    $terms = preg_split('/\s+/u', trim($search), -1, PREG_SPLIT_NO_EMPTY) ?: [];
    $terms = array_slice($terms, 0, 6);
    $parts = [];
    foreach ($terms as $i => $term) {
        $like = '%' . addcslashes($term, '\\%_') . '%';
        $likeNoDash = '%' . addcslashes(str_replace('-', '', $term), '\\%_') . '%';
        $parts[] = "({$alias}.name LIKE :s{$i}a OR {$alias}.part_number LIKE :s{$i}b OR REPLACE({$alias}.part_number, '-', '') LIKE :s{$i}c)";
        $params[":s{$i}a"] = $like;
        $params[":s{$i}b"] = $like;
        $params[":s{$i}c"] = $likeNoDash;
    }
    return $parts ? implode(' AND ', $parts) : '1=1';
}

/** يقتطع النص إلى طول أقصى (آمن للعربية) حتى لا يتجاوز حدود أعمدة قاعدة البيانات */
function limit_text(string $value, int $max): string
{
    return mb_strlen($value, 'UTF-8') > $max ? mb_substr($value, 0, $max, 'UTF-8') : $value;
}

/** يحوّل الأرقام العربية/الهندية (٠-٩ و ۰-۹) إلى لاتينية ويزيل فواصل الآلاف — لاستيراد الأسعار من Excel */
function normalize_number_string(string $value): string
{
    $value = strtr($value, [
        '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
        '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
        '٫'=>'.','٬'=>'',',' =>'',' '=>'',"\xC2\xA0"=>'',
    ]);
    return trim($value);
}

// ============================================================
// الطلبات
// ============================================================
function generate_order_number(): string
{
    return 'ORD-' . date('ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));
}

/**
 * إرسال إشعار بريدي بسيط عند وصول طلب جديد
 * يعتمد على دالة mail() المدمجة في PHP والمتاحة على Hostinger.
 * إذا واجهت مشاكل في وصول الرسائل، يُنصح لاحقًا باستخدام SMTP (راجع ملف README).
 */
function send_order_notification_email(array $order, array $items): void
{
    if (empty(ADMIN_NOTIFICATION_EMAIL) || !function_exists('mail')) {
        return;
    }

    $subject = '=?UTF-8?B?' . base64_encode('طلب جديد رقم ' . $order['order_number'] . ' - ' . SITE_NAME) . '?=';

    $body = "تم استلام طلب جديد على الموقع.\n\n";
    $body .= "رقم الطلب: {$order['order_number']}\n";
    $body .= "اسم العميل: {$order['customer_name']}\n";
    $body .= "الهاتف: {$order['phone']}\n";
    $body .= "واتساب: {$order['whatsapp']}\n";
    $body .= "البريد: {$order['email']}\n";
    $body .= "المدينة: {$order['city']}\n";
    $body .= "العنوان: {$order['address']}\n";
    $body .= "ملاحظات: {$order['notes']}\n\n";
    $body .= "تفاصيل الطلب:\n";

    foreach ($items as $item) {
        $body .= "- {$item['product_name']} (رقم القطعة: {$item['part_number']}) × {$item['quantity']} = " . number_format($item['subtotal'], 2) . " " . CURRENCY . "\n";
    }

    $body .= "\nالإجمالي قبل الضريبة: " . number_format($order['subtotal_amount'], 2) . " " . CURRENCY . "\n";
    $body .= 'الشحن: ' . ((float)($order['shipping_amount'] ?? 0) > 0 ? number_format($order['shipping_amount'], 2) . ' ' . CURRENCY : 'مجاني') . "\n";
    $body .= 'ضريبة القيمة المضافة (' . (VAT_RATE * 100) . "%): " . number_format($order['vat_amount'], 2) . " " . CURRENCY . "\n";
    $body .= "الإجمالي شامل الضريبة: " . number_format($order['total_amount'], 2) . " " . CURRENCY . "\n";
    $body .= 'طريقة الدفع: ' . payment_method_label($order['payment_method'] ?? 'cod') . "\n";

    $headers = 'Content-Type: text/plain; charset=UTF-8' . "\r\n";
    $headers .= 'From: no-reply@' . preg_replace('#^https?://#', '', rtrim(SITE_URL, '/')) . "\r\n";
    if (!empty($order['email']) && !preg_match('/[\r\n]/', $order['email']) && filter_var($order['email'], FILTER_VALIDATE_EMAIL)) {
        $headers .= 'Reply-To: ' . $order['email'] . "\r\n";
    }

    @mail(ADMIN_NOTIFICATION_EMAIL, $subject, $body, $headers);
}

// ============================================================
// أدوات عامة
// ============================================================
function redirect(string $path): void
{
    header('Location: ' . $path);
    exit;
}

function flash_set(string $key, string $message): void
{
    $_SESSION['flash'][$key] = $message;
}

function flash_get(string $key): ?string
{
    if (!empty($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
    return null;
}

function current_page(): string
{
    return basename($_SERVER['SCRIPT_NAME'], '.php');
}

// ============================================================
// أيقونات SVG بسيطة (لا تعتمد على أي مكتبة خارجية)
// ============================================================
function icon(string $name, string $class = 'icon'): string
{
    $paths = [
        'phone'      => '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>',
        'whatsapp'   => '<path d="M20.5 3.5A10.5 10.5 0 0 0 3.6 16.3L2 22l5.9-1.5A10.5 10.5 0 1 0 20.5 3.5z" fill="none"/><path d="M8.4 7.6c.2-.5.4-.5.7-.5h.5c.2 0 .4 0 .6.4.2.5.7 1.7.8 1.8.1.2.1.4 0 .6-.1.2-.2.3-.4.5-.2.2-.4.4-.2.7.2.4.9 1.4 1.9 2.3 1.3 1.2 2.3 1.5 2.7 1.7.3.2.5.1.7-.1l.6-.7c.2-.3.4-.2.7-.1.3.1 1.8.8 2.1.9.3.1.5.2.5.4 0 .2 0 1-.4 1.5-.4.6-1.7 1.1-2.4 1.1-.6 0-1.4 0-4.4-1.8-3.6-2.2-5.7-6-5.9-6.3-.2-.3-1.3-1.7-1.3-3.2 0-1.5.8-2.2 1.1-2.5z"/>',
        'email'      => '<path d="M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><polyline points="22,6 12,13 2,6"/>',
        'location'   => '<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>',
        'clock'      => '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
        'cart'       => '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"/>',
        'search'     => '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
        'menu'       => '<line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>',
        'close'      => '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
        'check'      => '<path d="M20 6 9 17l-5-5"/>',
        'shield'     => '<path d="M12 2 4 5v6c0 5 3.4 9 8 11 4.6-2 8-6 8-11V5l-8-3z"/>',
        'truck'      => '<rect x="1" y="6" width="14" height="11"/><path d="M15 9h4l3 3v5h-7z"/><circle cx="6" cy="19" r="2"/><circle cx="17" cy="19" r="2"/>',
        'badge'      => '<circle cx="12" cy="8" r="6"/><path d="M9 13.5 7 22l5-3 5 3-2-8.5"/>',
        'wrench'     => '<path d="M14.7 6.3a4 4 0 1 1-5.4 5.4L4 17l3 3 5.3-5.3a4 4 0 0 1 5.4-5.4l3-3-3-3z"/>',
        'engine'     => '<rect x="3" y="9" width="13" height="8" rx="1"/><path d="M16 11h3l2 2v4h-5z"/><circle cx="7" cy="17" r="1.6"/><path d="M6 9V6h3v3"/>',
        'brake'      => '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/>',
        'battery'    => '<rect x="2" y="8" width="18" height="9" rx="1"/><line x1="22" y1="11" x2="22" y2="14"/><line x1="6" y1="8" x2="6" y2="5"/><line x1="12" y1="8" x2="12" y2="5"/>',
        'tire'       => '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.5"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1"/>',
        'filter'     => '<path d="M4 4h16l-6 8v6l-4 2v-8z"/>',
        'suspension' => '<path d="M12 2v4M12 18v4M8 6l1.5 2M16 6l-1.5 2M8 18l1.5-2M16 18l-1.5-2"/><circle cx="12" cy="12" r="5"/>',
        'facebook'   => '<path d="M14 9h3V5h-3a4 4 0 0 0-4 4v2H7v4h3v7h4v-7h3l1-4h-4v-2a1 1 0 0 1 1-1z"/>',
        'instagram'  => '<rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1"/>',
        'twitter'    => '<path d="M22 4.9c-.8.3-1.6.6-2.4.7.9-.5 1.5-1.4 1.8-2.4-.8.5-1.7.8-2.7 1a4.2 4.2 0 0 0-7.2 3.8A12 12 0 0 1 2.9 3.6a4.2 4.2 0 0 0 1.3 5.6c-.7 0-1.3-.2-1.9-.5v.1c0 2 1.4 3.7 3.3 4.1-.6.1-1.2.2-1.8.1.5 1.7 2.1 2.9 3.9 2.9A8.4 8.4 0 0 1 2 18.6a11.9 11.9 0 0 0 6.4 1.9c7.7 0 11.9-6.4 11.9-11.9v-.5c.8-.6 1.5-1.3 2-2.1z"/>',
        'plus'       => '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
        'minus'      => '<line x1="5" y1="12" x2="19" y2="12"/>',
        'trash'      => '<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
        'edit'       => '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.1 2.1 0 0 1 3 3L12 15l-4 1 1-4z"/>',
        'logout'     => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
        'dashboard'  => '<rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/>',
        'box'        => '<path d="M21 8 12 3 3 8l9 5 9-5z"/><path d="M3 8v8l9 5 9-5V8"/><path d="M12 13v8"/>',
        'users'      => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        'mail-open'  => '<path d="M22 12v6a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-6"/><path d="M2 12 12 4l10 8"/><path d="M2 12l7 4 3-2 3 2 7-4"/>',
    ];
    $body = $paths[$name] ?? $paths['check'];
    return '<svg class="' . $class . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $body . '</svg>';
}
