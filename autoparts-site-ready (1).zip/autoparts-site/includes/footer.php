<footer class="site-footer">
    <div class="container footer-grid">
        <div class="footer-col">
            <h4><?= clean(SITE_NAME) ?></h4>
            <p style="font-size:14px;max-width:38ch"><?= clean(SITE_SLOGAN) ?></p>
            <div class="footer-social">
                <?php if (SOCIAL_FACEBOOK): ?><a href="<?= clean(SOCIAL_FACEBOOK) ?>" target="_blank" rel="noopener"><?= icon('facebook','icon-sm') ?></a><?php endif; ?>
                <?php if (SOCIAL_INSTAGRAM): ?><a href="<?= clean(SOCIAL_INSTAGRAM) ?>" target="_blank" rel="noopener"><?= icon('instagram','icon-sm') ?></a><?php endif; ?>
                <?php if (SOCIAL_TWITTER): ?><a href="<?= clean(SOCIAL_TWITTER) ?>" target="_blank" rel="noopener"><?= icon('twitter','icon-sm') ?></a><?php endif; ?>
            </div>
        </div>
        <div class="footer-col">
            <h4>روابط سريعة</h4>
            <ul>
                <li><a href="<?= base_url('index.php') ?>">الرئيسية</a></li>
                <li><a href="<?= base_url('products.php') ?>">قطع الغيار</a></li>
                <li><a href="<?= base_url('about.php') ?>">من نحن</a></li>
                <li><a href="<?= base_url('contact.php') ?>">تواصل معنا</a></li>
                <li><a href="<?= base_url('cart.php') ?>">سلة الطلب</a></li>
            </ul>
        </div>
        <div class="footer-col">
            <h4>تواصل معنا</h4>
            <ul>
                <li><?= icon('phone','icon-sm') ?> <?= clean(COMPANY_PHONE) ?></li>
                <li><?= icon('whatsapp','icon-sm') ?> <?= clean(COMPANY_WHATSAPP) ?></li>
                <li><?= icon('email','icon-sm') ?> <?= clean(COMPANY_EMAIL) ?></li>
            </ul>
        </div>
        <div class="footer-col">
            <h4>العنوان وساعات العمل</h4>
            <ul>
                <li><?= icon('location','icon-sm') ?> <?= clean(COMPANY_ADDRESS) ?></li>
                <li><?= icon('clock','icon-sm') ?> <?= clean(WORKING_HOURS) ?></li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom container">
        &copy; <?= date('Y') ?> <?= clean(SITE_NAME) ?> — جميع الحقوق محفوظة
    </div>
</footer>

<script>window.APP_BASE_URL = <?= json_encode(base_url('')) ?>;</script>
<script src="<?= base_url('assets/js/main.js') ?>"></script>
</body>
</html>
