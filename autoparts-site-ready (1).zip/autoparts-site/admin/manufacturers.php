<?php
require_once __DIR__ . '/includes/auth.php';
require_admin_login();

$pdo = get_db();
$errors = [];
$editing = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();
    $action = $_POST['form_action'] ?? '';

    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $pdo->prepare('DELETE FROM manufacturers WHERE id = :id')->execute([':id' => $id]);
        flash_set('success', 'تم حذف الشركة المصنعة. المنتجات المرتبطة بها أصبحت بدون شركة محددة.');
        redirect(base_url('admin/manufacturers.php'));
    }

    $name = sanitize_text($_POST['name'] ?? '');
    $id = (int)($_POST['id'] ?? 0);

    if ($name === '') $errors[] = 'الرجاء إدخال اسم الشركة المصنعة.';

    if (empty($errors)) {
        try {
            if ($id > 0) {
                $pdo->prepare('UPDATE manufacturers SET name = :n WHERE id = :id')->execute([':n' => $name, ':id' => $id]);
                flash_set('success', 'تم تحديث الشركة المصنعة بنجاح.');
            } else {
                $pdo->prepare('INSERT INTO manufacturers (name) VALUES (:n)')->execute([':n' => $name]);
                flash_set('success', 'تم إضافة الشركة المصنعة بنجاح.');
            }
            redirect(base_url('admin/manufacturers.php'));
        } catch (Throwable $e) {
            $errors[] = 'هذا الاسم موجود مسبقًا أو حدث خطأ أثناء الحفظ.';
        }
    }
}

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM manufacturers WHERE id = :id');
    $stmt->execute([':id' => (int)$_GET['edit']]);
    $editing = $stmt->fetch();
}

$manufacturers = $pdo->query("
    SELECT m.*, COUNT(p.id) AS product_count FROM manufacturers m
    LEFT JOIN products p ON p.manufacturer_id = m.id
    GROUP BY m.id ORDER BY m.name ASC
")->fetchAll();

$page_title = 'الشركات المصنعة';
require __DIR__ . '/includes/admin_header.php';
?>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger"><?php foreach ($errors as $e): ?><div><?= clean($e) ?></div><?php endforeach; ?></div>
<?php endif; ?>

<div class="filters-layout layout-main-side">
    <div class="admin-table-wrap">
        <table class="admin-table">
            <thead><tr><th>الاسم</th><th>عدد المنتجات</th><th></th></tr></thead>
            <tbody>
                <?php if (empty($manufacturers)): ?>
                    <tr><td colspan="3">لا توجد شركات مصنعة بعد.</td></tr>
                <?php endif; ?>
                <?php foreach ($manufacturers as $m): ?>
                <tr>
                    <td><?= clean($m['name']) ?></td>
                    <td><?= (int)$m['product_count'] ?></td>
                    <td class="action-icons">
                        <a href="<?= base_url('admin/manufacturers.php?edit=' . (int)$m['id']) ?>"><?= icon('edit','icon-sm') ?></a>
                        <form method="post" style="display:inline">
                            <?= csrf_field() ?>
                            <input type="hidden" name="form_action" value="delete">
                            <input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
                            <button type="submit" class="danger" data-confirm="حذف هذه الشركة المصنعة؟"><?= icon('trash','icon-sm') ?></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="card-box">
        <h3 style="font-size:16px"><?= $editing ? 'تعديل الشركة المصنعة' : 'إضافة شركة مصنعة' ?></h3>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= $editing['id'] ?? '' ?>">
            <div class="form-group">
                <label>اسم الشركة <span class="req">*</span></label>
                <input type="text" name="name" required value="<?= clean($editing['name'] ?? '') ?>">
            </div>
            <button type="submit" class="btn btn-accent btn-block"><?= $editing ? 'حفظ التعديلات' : 'إضافة' ?></button>
            <?php if ($editing): ?><a href="<?= base_url('admin/manufacturers.php') ?>" class="btn btn-dark btn-block" style="margin-top:8px">إلغاء</a><?php endif; ?>
        </form>
    </div>
</div>

<?php require __DIR__ . '/includes/admin_footer.php'; ?>
