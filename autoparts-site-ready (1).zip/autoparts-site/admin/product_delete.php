<?php
require_once __DIR__ . '/includes/auth.php';
require_admin_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(base_url('admin/products.php'));
}
require_valid_csrf();

$id = (int)($_POST['id'] ?? 0);
if ($id > 0) {
    $pdo = get_db();

    // حذف ملفات الصور الفعلية من السيرفر (الرئيسية + الإضافية)
    $stmt = $pdo->prepare('SELECT main_image FROM products WHERE id = :id');
    $stmt->execute([':id' => $id]);
    $product = $stmt->fetch();

    $imgStmt = $pdo->prepare('SELECT image_path FROM product_images WHERE product_id = :id');
    $imgStmt->execute([':id' => $id]);
    $extraImages = $imgStmt->fetchAll();

    $allPaths = array_merge(
        [$product['main_image'] ?? null],
        array_column($extraImages, 'image_path')
    );

    foreach ($allPaths as $path) {
        if ($path && str_starts_with($path, 'uploads/')) {
            $fullPath = __DIR__ . '/../' . $path;
            if (is_file($fullPath)) {
                @unlink($fullPath);
            }
        }
    }

    // حذف المنتج (سيحذف صفوف product_images تلقائيًا بفضل ON DELETE CASCADE)
    $pdo->prepare('DELETE FROM products WHERE id = :id')->execute([':id' => $id]);

    flash_set('success', 'تم حذف المنتج بنجاح.');
}

redirect(base_url('admin/products.php'));
