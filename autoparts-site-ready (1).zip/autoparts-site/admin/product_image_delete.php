<?php
require_once __DIR__ . '/includes/auth.php';
require_admin_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(base_url('admin/products.php'));
}
require_valid_csrf();

$imageId = (int)($_POST['image_id'] ?? 0);
$productId = (int)($_POST['product_id'] ?? 0);

if ($imageId > 0) {
    $pdo = get_db();
    $stmt = $pdo->prepare('SELECT image_path FROM product_images WHERE id = :id');
    $stmt->execute([':id' => $imageId]);
    $img = $stmt->fetch();

    if ($img && str_starts_with($img['image_path'], 'uploads/')) {
        $fullPath = __DIR__ . '/../' . $img['image_path'];
        if (is_file($fullPath)) {
            @unlink($fullPath);
        }
    }

    $pdo->prepare('DELETE FROM product_images WHERE id = :id')->execute([':id' => $imageId]);
    flash_set('success', 'تم حذف الصورة.');
}

redirect(base_url('admin/product_form.php?id=' . $productId));
