<?php
/**
 * هيدر لوحة التحكم المشترك — يتحقق من تسجيل الدخول تلقائيًا
 * الصفحة المستدعية يجب أن تُعرّف $page_title قبل تضمين هذا الملف
 */
require_once __DIR__ . '/auth.php';
require_admin_login();

$admin = current_admin();
$activeAdminPage = basename($_SERVER['SCRIPT_NAME'], '.php');
$page_title = $page_title ?? 'لوحة التحكم';

function admin_nav_active(string $page, array $matches): string
{
    return in_array($page, $matches, true) ? 'active' : '';
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= clean($page_title) ?> - لوحة التحكم</title>
<meta name="robots" content="noindex, nofollow">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600;700;800&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
<link rel="icon" href="<?= base_url('assets/images/logo/favicon-32.png') ?>" sizes="32x32">
<link rel="stylesheet" href="<?= base_url('admin/assets/admin.css') ?>">
<meta name="csrf-token" content="<?= csrf_token() ?>">
</head>
<body class="admin-body">
<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="admin-brand">
            <?= clean(SITE_NAME) ?>
            <span>لوحة التحكم</span>
        </div>
        <nav class="admin-nav">
            <a href="<?= base_url('admin/index.php') ?>" class="<?= admin_nav_active($activeAdminPage, ['index']) ?>"><?= icon('dashboard','icon-sm') ?> الرئيسية</a>

            <div class="nav-section-title">المنتجات</div>
            <a href="<?= base_url('admin/products.php') ?>" class="<?= admin_nav_active($activeAdminPage, ['products']) ?>"><?= icon('box','icon-sm') ?> المنتجات</a>
            <a href="<?= base_url('admin/product_form.php') ?>" class="<?= admin_nav_active($activeAdminPage, ['product_form']) ?>"><?= icon('plus','icon-sm') ?> إضافة منتج</a>
            <a href="<?= base_url('admin/bulk_images.php') ?>" class="<?= admin_nav_active($activeAdminPage, ['bulk_images']) ?>"><?= icon('box','icon-sm') ?> رفع صور القطع</a>
            <a href="<?= base_url('admin/bulk_update.php') ?>" class="<?= admin_nav_active($activeAdminPage, ['bulk_update']) ?>"><?= icon('edit','icon-sm') ?> تحديث الأسعار والمخزون (CSV)</a>
            <a href="<?= base_url('admin/categories.php') ?>" class="<?= admin_nav_active($activeAdminPage, ['categories']) ?>"><?= icon('filter','icon-sm') ?> الأقسام</a>
            <a href="<?= base_url('admin/manufacturers.php') ?>" class="<?= admin_nav_active($activeAdminPage, ['manufacturers']) ?>"><?= icon('badge','icon-sm') ?> الشركات المصنعة</a>

            <div class="nav-section-title">الطلبات والتواصل</div>
            <a href="<?= base_url('admin/orders.php') ?>" class="<?= admin_nav_active($activeAdminPage, ['orders', 'order_view']) ?>"><?= icon('truck','icon-sm') ?> الطلبات</a>
            <a href="<?= base_url('admin/messages.php') ?>" class="<?= admin_nav_active($activeAdminPage, ['messages']) ?>"><?= icon('mail-open','icon-sm') ?> رسائل التواصل</a>

            <div class="nav-section-title">الموقع</div>
            <a href="<?= base_url('index.php') ?>" target="_blank"><?= icon('search','icon-sm') ?> عرض الموقع</a>
            <a href="<?= base_url('admin/logout.php') ?>"><?= icon('logout','icon-sm') ?> تسجيل الخروج</a>
        </nav>
    </aside>

    <main class="admin-main">
        <div class="admin-topbar">
            <h1><?= clean($page_title) ?></h1>
            <div class="admin-user-chip"><?= icon('users','icon-sm') ?> <?= clean($admin['full_name'] ?: $admin['username']) ?></div>
        </div>

        <?php if ($msg = flash_get('success')): ?><div class="alert alert-success"><?= clean($msg) ?></div><?php endif; ?>
        <?php if ($msg = flash_get('error')): ?><div class="alert alert-danger"><?= clean($msg) ?></div><?php endif; ?>
