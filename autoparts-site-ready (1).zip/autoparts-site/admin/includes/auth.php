<?php
/**
 * دوال المصادقة الخاصة بلوحة التحكم
 */
require_once __DIR__ . '/../../includes/functions.php';
start_app_session();

const ADMIN_SESSION_KEY = 'admin_user';
const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_SECONDS = 900; // 15 دقيقة

function admin_logged_in(): bool
{
    return !empty($_SESSION[ADMIN_SESSION_KEY]['id']);
}

function current_admin(): ?array
{
    return $_SESSION[ADMIN_SESSION_KEY] ?? null;
}

function require_admin_login(): void
{
    if (!admin_logged_in()) {
        redirect(base_url('admin/login.php'));
    }
}

function admin_has_any_account(): bool
{
    $pdo = get_db();
    return (int)$pdo->query('SELECT COUNT(*) FROM admin_users')->fetchColumn() > 0;
}

/** عنوان IP للزائر (يعتمد على REMOTE_ADDR فقط حتى لا يُزوَّر عبر رؤوس HTTP) */
function client_ip(): string
{
    return substr((string)($_SERVER['REMOTE_ADDR'] ?? 'unknown'), 0, 45);
}

/**
 * حدّ محاولات الدخول على مستوى IP (في قاعدة البيانات) إضافةً إلى حد الجلسة،
 * فلا يمكن تجاوزه بحذف الكوكيز. إن لم يوجد جدول login_attempts يُتجاهل بصمت.
 */
function ip_is_locked_out(): bool
{
    try {
        $stmt = get_db()->prepare('SELECT COUNT(*) FROM login_attempts WHERE ip = :ip AND attempted_at > (NOW() - INTERVAL ' . (int)LOCKOUT_SECONDS . ' SECOND)');
        $stmt->execute([':ip' => client_ip()]);
        return (int)$stmt->fetchColumn() >= MAX_LOGIN_ATTEMPTS * 2;
    } catch (Throwable $e) {
        return false;
    }
}

function register_ip_failure(): void
{
    try {
        get_db()->prepare('INSERT INTO login_attempts (ip) VALUES (:ip)')->execute([':ip' => client_ip()]);
        get_db()->exec('DELETE FROM login_attempts WHERE attempted_at < (NOW() - INTERVAL 1 DAY)');
    } catch (Throwable $e) {
        // الجدول غير موجود: نكتفي بحماية الجلسة
    }
}

function clear_ip_failures(): void
{
    try {
        get_db()->prepare('DELETE FROM login_attempts WHERE ip = :ip')->execute([':ip' => client_ip()]);
    } catch (Throwable $e) {
    }
}

function login_is_locked_out(): bool
{
    if (ip_is_locked_out()) {
        return true;
    }
    $lock = $_SESSION['admin_lockout'] ?? null;
    if (!$lock) {
        return false;
    }
    if (($lock['attempts'] ?? 0) < MAX_LOGIN_ATTEMPTS) {
        return false;
    }
    if (time() - ($lock['last_attempt'] ?? 0) > LOCKOUT_SECONDS) {
        unset($_SESSION['admin_lockout']);
        return false;
    }
    return true;
}

function register_failed_login(): void
{
    if (!isset($_SESSION['admin_lockout'])) {
        $_SESSION['admin_lockout'] = ['attempts' => 0, 'last_attempt' => time()];
    }
    $_SESSION['admin_lockout']['attempts']++;
    $_SESSION['admin_lockout']['last_attempt'] = time();
}

function clear_login_attempts(): void
{
    unset($_SESSION['admin_lockout']);
}

function attempt_admin_login(string $username, string $password): array
{
    if (login_is_locked_out()) {
        return ['success' => false, 'message' => 'تم إيقاف تسجيل الدخول مؤقتًا بسبب محاولات كثيرة فاشلة. حاول لاحقًا خلال 15 دقيقة.'];
    }

    $pdo = get_db();
    $stmt = $pdo->prepare('SELECT * FROM admin_users WHERE username = :u LIMIT 1');
    $stmt->execute([':u' => $username]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        register_failed_login();
        register_ip_failure();
        return ['success' => false, 'message' => 'اسم المستخدم أو كلمة المرور غير صحيحة.'];
    }

    clear_login_attempts();
    clear_ip_failures();
    session_regenerate_id(true);

    $_SESSION[ADMIN_SESSION_KEY] = [
        'id'        => $user['id'],
        'username'  => $user['username'],
        'full_name' => $user['full_name'],
    ];

    $pdo->prepare('UPDATE admin_users SET last_login = NOW() WHERE id = :id')->execute([':id' => $user['id']]);

    return ['success' => true];
}

function admin_logout(): void
{
    unset($_SESSION[ADMIN_SESSION_KEY]);
    session_regenerate_id(true);
}
