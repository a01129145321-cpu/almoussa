    </main>
</div>
<script>window.APP_BASE_URL = <?= json_encode(base_url('')) ?>;</script>
<script src="<?= base_url('admin/assets/admin.js') ?>"></script>
</body>
</html>
