<?php
require_once __DIR__ . '/includes/auth.php';
require_admin_login();

$pdo = get_db();

$status = $_GET['status'] ?? '';
$validStatuses = ['new', 'processing', 'confirmed', 'shipped', 'completed', 'cancelled'];
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;

$where = '1=1';
$params = [];
if (in_array($status, $validStatuses, true)) {
    $where = 'status = :status';
    $params[':status'] = $status;
}

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE $where");
$countStmt->execute($params);
$totalItems = (int)$countStmt->fetchColumn();
$totalPages = max(1, (int)ceil($totalItems / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

$stmt = $pdo->prepare("SELECT * FROM orders WHERE $where ORDER BY created_at DESC, id DESC LIMIT :limit OFFSET :offset");
foreach ($params as $k => $v) $stmt->bindValue($k, $v);
$stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$orders = $stmt->fetchAll();

// عدد الطلبات لكل حالة (لأزرار التصفية)
$statusCounts = [];
foreach ($pdo->query("SELECT status, COUNT(*) AS c FROM orders GROUP BY status")->fetchAll() as $row) {
    $statusCounts[$row['status']] = (int)$row['c'];
}

$page_title = 'إدارة الطلبات';
require __DIR__ . '/includes/admin_header.php';
?>

<div class="toolbar">
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <a href="<?= base_url('admin/orders.php') ?>" class="btn btn-sm <?= $status === '' ? 'btn-accent' : 'btn-dark' ?>">
            الكل (<?= array_sum($statusCounts) ?>)
        </a>
        <?php foreach ($validStatuses as $s): ?>
        <a href="<?= base_url('admin/orders.php?status=' . $s) ?>" class="btn btn-sm <?= $status === $s ? 'btn-accent' : 'btn-dark' ?>">
            <?= order_status_label($s) ?> (<?= $statusCounts[$s] ?? 0 ?>)
        </a>
        <?php endforeach; ?>
    </div>
</div>

<div class="admin-table-wrap">
    <table class="admin-table">
        <thead>
            <tr><th>رقم الطلب</th><th>العميل</th><th>الهاتف</th><th>المدينة</th><th>الإجمالي</th><th>الدفع</th><th>الحالة</th><th>التاريخ</th><th></th></tr>
        </thead>
        <tbody>
            <?php if (empty($orders)): ?>
                <tr><td colspan="9">لا توجد طلبات في هذه الحالة.</td></tr>
            <?php endif; ?>
            <?php foreach ($orders as $o): ?>
            <tr>
                <td><?= clean($o['order_number']) ?></td>
                <td><?= clean($o['customer_name']) ?></td>
                <td dir="ltr"><?= clean($o['phone']) ?></td>
                <td><?= clean($o['city']) ?></td>
                <td><?= format_price((float)$o['total_amount']) ?></td>
                <td>
                    <?= payment_method_label($o['payment_method']) ?>
                    <?php if ($o['payment_method'] === 'bank_transfer'): ?>
                        <br><span class="status-pill <?= $o['payment_status'] === 'paid' ? 'badge-success' : 'badge-warning' ?>" style="margin-top:2px"><?= payment_status_label($o['payment_status']) ?></span>
                    <?php endif; ?>
                </td>
                <td><span class="status-pill <?= $o['status'] === 'new' ? 'badge-warning' : ($o['status'] === 'cancelled' ? 'badge-danger' : 'badge-success') ?>"><?= order_status_label($o['status']) ?></span></td>
                <td><?= date('Y-m-d H:i', strtotime($o['created_at'])) ?></td>
                <td class="action-icons">
                    <a href="<?= base_url('admin/order_view.php?id=' . (int)$o['id']) ?>" title="عرض التفاصيل"><?= icon('search','icon-sm') ?></a>
                    <a href="<?= whatsapp_link('مرحبًا ' . $o['customer_name'] . '، بخصوص طلبك رقم ' . $o['order_number']) ?>" target="_blank" rel="noopener" title="واتساب"><?= icon('whatsapp','icon-sm') ?></a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php if ($totalPages > 1): ?>
<div class="pagination">
    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <a href="<?= base_url('admin/orders.php?status=' . $status . '&page=' . $i) ?>" class="<?= $i === $page ? 'active' : '' ?>"><?= $i ?></a>
    <?php endfor; ?>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/admin_footer.php'; ?>
