<?php
require_once __DIR__ . '/includes/auth.php';
require_admin_login();

$pdo = get_db();

// ============ تصدير CSV ============
if (isset($_GET['export'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="products-price-stock-' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    fputs($out, "\xEF\xBB\xBF"); // BOM حتى يفتح Excel الملف بالعربي بشكل صحيح
    fputcsv($out, ['part_number', 'name', 'price', 'stock_quantity', 'availability']);

    $stmt = $pdo->query('SELECT part_number, name, price, stock_quantity, availability FROM products ORDER BY name ASC');
    while ($row = $stmt->fetch()) {
        fputcsv($out, [$row['part_number'], $row['name'], $row['price'], $row['stock_quantity'], $row['availability']]);
    }
    fclose($out);
    exit;
}

// ============ استيراد CSV ============
$report = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();

    if (empty($_FILES['csv_file']['tmp_name']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
        flash_set('error', 'الرجاء اختيار ملف CSV صالح.');
        redirect(base_url('admin/bulk_update.php'));
    }

    // Excel بالعربية قد يحفظ CSV بفاصلة منقوطة (;) أو بترميز Windows-1256 بدل UTF-8: نكتشف ذلك تلقائيًا ونحوّله لملف UTF-8 مؤقت
    $raw = (string)file_get_contents($_FILES['csv_file']['tmp_name']);
    $raw = preg_replace('/^\xEF\xBB\xBF/', '', $raw);
    if (!mb_check_encoding($raw, 'UTF-8')) {
        // mbstring لا يدعم Windows-1256، لذا نستخدم iconv (متوفر في Hostinger)
        $converted = function_exists('iconv') ? @iconv('Windows-1256', 'UTF-8//IGNORE', $raw) : false;
        if ($converted === false) {
            flash_set('error', 'تعذر قراءة ترميز الملف. احفظه من Excel بصيغة "CSV UTF-8 (محدد بفواصل)" ثم أعد رفعه.');
            redirect(base_url('admin/bulk_update.php'));
        }
        $raw = $converted;
    }
    $firstLine = strtok($raw, "\n") ?: '';
    $delimiter = ',';
    foreach ([';', "\t"] as $cand) {
        if (substr_count($firstLine, $cand) > substr_count($firstLine, $delimiter)) {
            $delimiter = $cand;
        }
    }
    $handle = fopen('php://temp', 'r+');
    fwrite($handle, $raw);
    rewind($handle);
    unset($raw);
    $header = fgetcsv($handle, 0, $delimiter);
    // إزالة BOM المحتمل من أول عمود، وتوحيد أسماء الأعمدة بأحرف صغيرة بدون فراغات
    if ($header) {
        $header[0] = preg_replace('/^\xEF\xBB\xBF/', '', $header[0]);
        $header = array_map(fn($h) => strtolower(trim($h)), $header);
    }
    if (!$header) {
        fclose($handle);
        flash_set('error', 'الملف فارغ أو غير مقروء.');
        redirect(base_url('admin/bulk_update.php'));
    }
    $colPart = array_search('part_number', $header, true);
    $colPrice = array_search('price', $header, true);
    $colStock = array_search('stock_quantity', $header, true);
    $colAvail = array_search('availability', $header, true);

    if ($colPart === false || $colPrice === false) {
        fclose($handle);
        flash_set('error', 'الملف يجب أن يحتوي على عمودي part_number و price على الأقل (استخدم زر "تصدير" أولًا للحصول على القالب الصحيح).');
        redirect(base_url('admin/bulk_update.php'));
    }

    $updateStmt = $pdo->prepare('UPDATE products SET price = :price, stock_quantity = :stock, availability = :avail WHERE part_number = :part');
    $findStmt = $pdo->prepare('SELECT stock_quantity FROM products WHERE part_number = :part');

    $updated = 0; $notFound = []; $invalid = [];
    $rowNum = 1;

    $pdo->beginTransaction();
    while (($row = fgetcsv($handle, 0, $delimiter)) !== false) {
        $rowNum++;
        $part = trim($row[$colPart] ?? '');
        if ($part === '') { continue; }

        $priceRaw = normalize_number_string((string)($row[$colPrice] ?? ''));
        if ($priceRaw === '' || !is_numeric($priceRaw) || (float)$priceRaw < 0) {
            $invalid[] = "صف {$rowNum} ({$part}): سعر غير صالح";
            continue;
        }
        $price = (float)$priceRaw;

        $findStmt->execute([':part' => $part]);
        $existing = $findStmt->fetch();
        if (!$existing) {
            $notFound[] = $part;
            continue;
        }

        $stock = $colStock !== false && trim((string)($row[$colStock] ?? '')) !== ''
            ? max(0, (int)normalize_number_string((string)$row[$colStock]))
            : (int)$existing['stock_quantity'];

        $requestedAvail = $colAvail !== false ? trim((string)($row[$colAvail] ?? '')) : 'available';
        if (!in_array($requestedAvail, ['available', 'out_of_stock', 'on_order'], true)) {
            $requestedAvail = 'available';
        }
        $availability = resolve_availability($stock, $requestedAvail);

        $updateStmt->execute([':price' => $price, ':stock' => $stock, ':avail' => $availability, ':part' => $part]);
        $updated++;
    }
    $pdo->commit();
    fclose($handle);

    $report = ['updated' => $updated, 'not_found' => $notFound, 'invalid' => $invalid];
}

$total = (int)$pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();

$page_title = 'تحديث الأسعار والمخزون بالجملة';
require __DIR__ . '/includes/admin_header.php';
?>

<div class="card-box" style="max-width:820px;margin-bottom:20px">
    <h3 style="font-size:16px;margin-bottom:8px">1) صدّر الملف الحالي</h3>
    <p style="color:var(--color-text-muted);font-size:14px">
        يصدّر ملف CSV بكل المنتجات (<?= $total ?> منتجًا) بأعمدة: رقم القطعة، الاسم، السعر، الكمية، حالة التوفر.
        افتحه في Excel وعدّل الأسعار أو الكميات التي تريدها، ثم احفظه بصيغة CSV وارفعه بالأسفل.
    </p>
    <a href="<?= base_url('admin/bulk_update.php?export=1') ?>" class="btn btn-dark"><?= icon('box','icon-sm') ?> تصدير الأسعار والمخزون (CSV)</a>
</div>

<div class="card-box" style="max-width:820px">
    <h3 style="font-size:16px;margin-bottom:8px">2) ارفع الملف بعد التعديل</h3>
    <p style="color:var(--color-text-muted);font-size:14px">
        يُحدَّث السعر والكمية <b>فقط للمنتجات الموجودة مسبقًا</b> بمطابقة عمود «رقم القطعة» — هذه الأداة لا تضيف منتجات جديدة
        ولا تحذف شيئًا. لإضافة منتج جديد استخدم صفحة «إضافة منتج».
        عمود الكمية وعمود حالة التوفر اختياريان: إن تركتهما فارغين تبقى الكمية كما هي.
    </p>
    <form method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <div class="form-group">
            <label>ملف CSV</label>
            <input type="file" name="csv_file" accept=".csv,text/csv" required>
        </div>
        <button type="submit" class="btn btn-accent"><?= icon('check','icon-sm') ?> رفع وتحديث الأسعار والمخزون</button>
    </form>
</div>

<?php if ($report): ?>
<div class="card-box" style="max-width:820px;margin-top:20px">
    <h3 style="font-size:16px;margin-bottom:12px">نتيجة الاستيراد</h3>
    <p><span class="status-pill badge-success">تم تحديث <?= $report['updated'] ?> منتجًا</span></p>

    <?php if (!empty($report['not_found'])): ?>
        <p style="margin-top:14px"><b><?= count($report['not_found']) ?></b> رقم قطعة غير موجود في قاعدة البيانات (لم يُحدَّث):</p>
        <div class="admin-table-wrap" style="max-height:260px;overflow-y:auto">
            <table class="admin-table"><tbody>
                <?php foreach (array_slice($report['not_found'], 0, 200) as $p): ?>
                    <tr><td dir="ltr"><?= clean($p) ?></td></tr>
                <?php endforeach; ?>
            </tbody></table>
        </div>
        <?php if (count($report['not_found']) > 200): ?><p style="font-size:12px;color:var(--color-text-muted)">وأكثر من ذلك (تم عرض أول 200 فقط)...</p><?php endif; ?>
    <?php endif; ?>

    <?php if (!empty($report['invalid'])): ?>
        <p style="margin-top:14px"><b><?= count($report['invalid']) ?></b> صف بقيمة سعر غير صالحة (تم تجاهله):</p>
        <div class="admin-table-wrap" style="max-height:200px;overflow-y:auto">
            <table class="admin-table"><tbody>
                <?php foreach ($report['invalid'] as $msg): ?><tr><td><?= clean($msg) ?></td></tr><?php endforeach; ?>
            </tbody></table>
        </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/admin_footer.php'; ?>
