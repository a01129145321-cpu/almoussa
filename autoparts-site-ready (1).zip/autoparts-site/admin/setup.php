<?php
/**
 * معالج الإعداد الأول للوحة التحكم
 * يعمل فقط إذا لم يوجد أي حساب مدير في قاعدة البيانات بعد.
 * بمجرد إنشاء أول حساب، يتوقف هذا الملف عن العمل تلقائيًا لأسباب أمنية.
 * يُنصح بحذف هذا الملف بعد الانتهاء من الإعداد.
 */
require_once __DIR__ . '/includes/auth.php';

if (admin_has_any_account()) {
    http_response_code(403);
    die('تم إعداد لوحة التحكم مسبقًا. لأسباب أمنية هذه الصفحة معطّلة الآن. يمكنك حذف ملف admin/setup.php. لتسجيل الدخول توجه إلى admin/login.php');
}

$errors = [];
$username = '';
$fullName = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();

    $username = trim($_POST['username'] ?? '');
    $fullName = trim($_POST['full_name'] ?? '');
    $password = (string)($_POST['password'] ?? '');
    $passwordConfirm = (string)($_POST['password_confirm'] ?? '');

    if (mb_strlen($username) < 3) $errors[] = 'اسم المستخدم يجب أن يكون 3 أحرف على الأقل.';
    if (!preg_match('/^[a-zA-Z0-9_\.]+$/', $username)) $errors[] = 'اسم المستخدم يجب أن يحتوي على حروف/أرقام إنجليزية فقط دون مسافات.';
    if (mb_strlen($password) < 8) $errors[] = 'كلمة المرور يجب أن تكون 8 أحرف على الأقل.';
    if ($password !== $passwordConfirm) $errors[] = 'كلمتا المرور غير متطابقتين.';

    if (empty($errors)) {
        $pdo = get_db();
        $stmt = $pdo->prepare('INSERT INTO admin_users (username, password_hash, full_name) VALUES (:u, :p, :f)');
        $stmt->execute([
            ':u' => $username,
            ':p' => password_hash($password, PASSWORD_DEFAULT),
            ':f' => $fullName ?: null,
        ]);

        // حماية إضافية: نحاول حذف ملف الإعداد تلقائيًا بعد نجاح إنشاء الحساب
        $deleted = @unlink(__FILE__);
        flash_set('success', $deleted
            ? 'تم إنشاء حساب المدير بنجاح، وتم حذف ملف الإعداد تلقائيًا لأسباب أمنية. سجّل دخولك الآن.'
            : 'تم إنشاء حساب المدير بنجاح. سجّل دخولك الآن، واحذف ملف admin/setup.php من الاستضافة يدويًا.');
        redirect(base_url('admin/login.php'));
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>إعداد لوحة التحكم لأول مرة</title>
<meta name="robots" content="noindex, nofollow">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600;700;800&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
<link rel="icon" href="<?= base_url('assets/images/logo/favicon-32.png') ?>" sizes="32x32">
<link rel="stylesheet" href="<?= base_url('admin/assets/admin.css') ?>">
</head>
<body class="admin-auth-body">
<div class="admin-auth-box">
    <h1 class="font-display" style="font-size:22px">إعداد لوحة التحكم لأول مرة</h1>
    <p style="color:var(--color-text-muted)">أنشئ حساب المدير الأول للوصول إلى لوحة التحكم. هذه الخطوة تظهر مرة واحدة فقط.</p>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger"><?php foreach ($errors as $e): ?><div><?= clean($e) ?></div><?php endforeach; ?></div>
    <?php endif; ?>

    <form method="post">
        <?= csrf_field() ?>
        <div class="form-group">
            <label>اسم المستخدم <span class="req">*</span></label>
            <input type="text" name="username" required value="<?= clean($username) ?>" placeholder="مثال: admin" dir="ltr">
        </div>
        <div class="form-group">
            <label>الاسم الكامل (اختياري)</label>
            <input type="text" name="full_name" value="<?= clean($fullName) ?>">
        </div>
        <div class="form-group">
            <label>كلمة المرور <span class="req">*</span></label>
            <input type="password" name="password" required minlength="8">
        </div>
        <div class="form-group">
            <label>تأكيد كلمة المرور <span class="req">*</span></label>
            <input type="password" name="password_confirm" required minlength="8">
        </div>
        <button type="submit" class="btn btn-accent btn-block">إنشاء الحساب</button>
    </form>
</div>
</body>
</html>
