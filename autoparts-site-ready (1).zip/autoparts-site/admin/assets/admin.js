(function () {
  'use strict';

  // تأكيد قبل أي عملية حذف
  document.querySelectorAll('[data-confirm]').forEach(function (el) {
    el.addEventListener('click', function (e) {
      var msg = el.getAttribute('data-confirm') || 'هل أنت متأكد من هذا الإجراء؟';
      if (!confirm(msg)) {
        e.preventDefault();
      }
    });
  });

  // معاينة الصورة قبل الرفع
  document.querySelectorAll('[data-image-input]').forEach(function (input) {
    input.addEventListener('change', function () {
      var previewId = input.getAttribute('data-image-input');
      var preview = document.getElementById(previewId);
      if (!preview || !input.files || !input.files[0]) return;
      var reader = new FileReader();
      reader.onload = function (e) { preview.src = e.target.result; };
      reader.readAsDataURL(input.files[0]);
    });
  });
})();
