<?php
require_once __DIR__ . '/includes/auth.php';
require_admin_login();

$pdo = get_db();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$isEdit = $id > 0;

$product = [
    'name' => '', 'part_number' => '', 'category_id' => '', 'manufacturer_id' => '',
    'price' => '', 'old_price' => '', 'description' => '', 'compatible_cars' => '',
    'availability' => 'available', 'stock_quantity' => 0, 'main_image' => null, 'is_featured' => 0,
];

if ($isEdit) {
    $stmt = $pdo->prepare('SELECT * FROM products WHERE id = :id');
    $stmt->execute([':id' => $id]);
    $found = $stmt->fetch();
    if (!$found) {
        flash_set('error', 'المنتج غير موجود.');
        redirect(base_url('admin/products.php'));
    }
    $product = $found;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();

    $product['name'] = sanitize_text($_POST['name'] ?? '');
    $product['part_number'] = sanitize_text($_POST['part_number'] ?? '');
    $product['category_id'] = (int)($_POST['category_id'] ?? 0) ?: null;
    $product['manufacturer_id'] = (int)($_POST['manufacturer_id'] ?? 0) ?: null;
    $product['price'] = (float)($_POST['price'] ?? 0);
    $product['old_price'] = ($_POST['old_price'] ?? '') !== '' ? (float)$_POST['old_price'] : null;
    $product['description'] = sanitize_text($_POST['description'] ?? '');
    $product['compatible_cars'] = sanitize_text($_POST['compatible_cars'] ?? '');
    $product['availability'] = in_array($_POST['availability'] ?? '', ['available', 'out_of_stock', 'on_order'], true) ? $_POST['availability'] : 'available';
    $product['stock_quantity'] = max(0, (int)($_POST['stock_quantity'] ?? 0));
    $product['availability'] = resolve_availability($product['stock_quantity'], $product['availability']);
    $product['is_featured'] = !empty($_POST['is_featured']) ? 1 : 0;

    if ($product['name'] === '') $errors[] = 'الرجاء إدخال اسم المنتج.';
    if ($product['part_number'] === '') $errors[] = 'الرجاء إدخال رقم القطعة.';
    if ($product['price'] <= 0) $errors[] = 'الرجاء إدخال سعر صحيح أكبر من صفر.';
    if ($product['price'] >= 100000000) $errors[] = 'السعر كبير جدًا.';
    if ($product['old_price'] !== null && $product['old_price'] >= 100000000) $errors[] = 'السعر قبل الخصم كبير جدًا.';
    if (mb_strlen($product['name']) > 200) $errors[] = 'اسم المنتج طويل (الحد الأقصى 200 حرف).';
    if (mb_strlen($product['part_number']) > 100) $errors[] = 'رقم القطعة طويل (الحد الأقصى 100 حرف).';
    if ($product['stock_quantity'] > 1000000) $errors[] = 'الكمية كبيرة جدًا.';

    if ($product['part_number'] !== '' && empty($errors)) {
        $dup = $pdo->prepare('SELECT id, name FROM products WHERE part_number = :pn AND id != :id LIMIT 1');
        $dup->execute([':pn' => $product['part_number'], ':id' => $id ?: 0]);
        if ($row = $dup->fetch()) {
            $errors[] = 'رقم القطعة هذا مستخدم مسبقًا في المنتج: ' . $row['name'] . ' — عدّل ذلك المنتج بدل إنشاء نسخة مكررة.';
        }
    }

    // رفع الصورة الرئيسية (اختياري عند التعديل، إجباري منطقيًا عند الإضافة لكن غير مانع)
    $uploadResult = empty($errors) ? handle_product_image_upload($_FILES['main_image'] ?? []) : null;
    if ($uploadResult && isset($uploadResult['error'])) {
        $errors[] = $uploadResult['error'];
    }

    if (empty($errors)) {
        $slugBase = slugify($product['name']);
        $slug = $slugBase;

        $pdo = get_db();

        // ضمان تفرد الـ slug
        $i = 1;
        while (true) {
            $check = $pdo->prepare('SELECT id FROM products WHERE slug = :slug AND id != :id');
            $check->execute([':slug' => $slug, ':id' => $id ?: 0]);
            if (!$check->fetch()) break;
            $slug = $slugBase . '-' . (++$i);
        }

        $mainImage = $product['main_image'];
        if ($uploadResult && isset($uploadResult['path'])) {
            $mainImage = $uploadResult['path'];
        }

        if ($isEdit) {
            $sql = "UPDATE products SET name=:name, slug=:slug, part_number=:part_number, category_id=:category_id,
                    manufacturer_id=:manufacturer_id, price=:price, old_price=:old_price, description=:description,
                    compatible_cars=:compatible_cars, availability=:availability, stock_quantity=:stock_quantity, main_image=:main_image, is_featured=:is_featured
                    WHERE id=:id";
            $params = [
                ':name' => $product['name'], ':slug' => $slug, ':part_number' => $product['part_number'],
                ':category_id' => $product['category_id'], ':manufacturer_id' => $product['manufacturer_id'],
                ':price' => $product['price'], ':old_price' => $product['old_price'], ':description' => $product['description'],
                ':compatible_cars' => $product['compatible_cars'], ':availability' => $product['availability'], ':stock_quantity' => $product['stock_quantity'],
                ':main_image' => $mainImage, ':is_featured' => $product['is_featured'], ':id' => $id,
            ];
        } else {
            $sql = "INSERT INTO products (name, slug, part_number, category_id, manufacturer_id, price, old_price,
                    description, compatible_cars, availability, stock_quantity, main_image, is_featured)
                    VALUES (:name, :slug, :part_number, :category_id, :manufacturer_id, :price, :old_price,
                    :description, :compatible_cars, :availability, :stock_quantity, :main_image, :is_featured)";
            $params = [
                ':name' => $product['name'], ':slug' => $slug, ':part_number' => $product['part_number'],
                ':category_id' => $product['category_id'], ':manufacturer_id' => $product['manufacturer_id'],
                ':price' => $product['price'], ':old_price' => $product['old_price'], ':description' => $product['description'],
                ':compatible_cars' => $product['compatible_cars'], ':availability' => $product['availability'], ':stock_quantity' => $product['stock_quantity'],
                ':main_image' => $mainImage, ':is_featured' => $product['is_featured'],
            ];
        }

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $id = $isEdit ? $id : (int)$pdo->lastInsertId();

        // صور إضافية (يمكن رفع أكثر من صورة دفعة واحدة)
        if (!empty($_FILES['gallery_images']['name'][0] ?? '')) {
            $count = count($_FILES['gallery_images']['name']);
            for ($i = 0; $i < $count; $i++) {
                $file = [
                    'name' => $_FILES['gallery_images']['name'][$i],
                    'type' => $_FILES['gallery_images']['type'][$i],
                    'tmp_name' => $_FILES['gallery_images']['tmp_name'][$i],
                    'error' => $_FILES['gallery_images']['error'][$i],
                    'size' => $_FILES['gallery_images']['size'][$i],
                ];
                $res = handle_product_image_upload($file);
                if ($res && isset($res['path'])) {
                    $pdo->prepare('INSERT INTO product_images (product_id, image_path, sort_order) VALUES (:pid, :path, 0)')
                        ->execute([':pid' => $id, ':path' => $res['path']]);
                }
            }
        }

        flash_set('success', $isEdit ? 'تم تحديث المنتج بنجاح.' : 'تم إضافة المنتج بنجاح.');
        redirect(base_url('admin/products.php'));
    }
}

$categories = $pdo->query('SELECT * FROM categories ORDER BY name ASC')->fetchAll();
$manufacturers = $pdo->query('SELECT * FROM manufacturers ORDER BY name ASC')->fetchAll();

$galleryImages = [];
if ($isEdit) {
    $g = $pdo->prepare('SELECT * FROM product_images WHERE product_id = :id ORDER BY sort_order ASC');
    $g->execute([':id' => $id]);
    $galleryImages = $g->fetchAll();
}

$page_title = $isEdit ? 'تعديل منتج' : 'إضافة منتج جديد';
require __DIR__ . '/includes/admin_header.php';
?>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger"><?php foreach ($errors as $e): ?><div><?= clean($e) ?></div><?php endforeach; ?></div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data" class="card-box" style="max-width:920px">
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group">
            <label>اسم المنتج <span class="req">*</span></label>
            <input type="text" name="name" required value="<?= clean($product['name']) ?>">
        </div>
        <div class="form-group">
            <label>رقم القطعة (Part Number) <span class="req">*</span></label>
            <input type="text" name="part_number" required dir="ltr" value="<?= clean($product['part_number']) ?>">
        </div>
        <div class="form-group">
            <label>القسم</label>
            <select name="category_id">
                <option value="">— اختر القسم —</option>
                <?php foreach ($categories as $c): ?>
                    <option value="<?= $c['id'] ?>" <?= (string)$product['category_id'] === (string)$c['id'] ? 'selected' : '' ?>><?= clean($c['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label>الشركة المصنعة</label>
            <select name="manufacturer_id">
                <option value="">— اختر الشركة —</option>
                <?php foreach ($manufacturers as $m): ?>
                    <option value="<?= $m['id'] ?>" <?= (string)$product['manufacturer_id'] === (string)$m['id'] ? 'selected' : '' ?>><?= clean($m['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label>السعر (<?= CURRENCY ?>) <span class="req">*</span></label>
            <input type="number" step="0.01" min="0" name="price" required value="<?= clean((string)$product['price']) ?>">
        </div>
        <div class="form-group">
            <label>السعر قبل الخصم (اختياري)</label>
            <input type="number" step="0.01" min="0" name="old_price" value="<?= clean((string)($product['old_price'] ?? '')) ?>">
        </div>
        <div class="form-group">
            <label>الكمية المتوفرة</label>
            <input type="number" min="0" name="stock_quantity" value="<?= (int)$product['stock_quantity'] ?>">
        </div>
        <div class="form-group">
            <label>حالة التوفر</label>
            <select name="availability">
                <option value="available" <?= $product['availability'] === 'available' ? 'selected' : '' ?>>متوفر</option>
                <option value="out_of_stock" <?= $product['availability'] === 'out_of_stock' ? 'selected' : '' ?>>غير متوفر</option>
                <option value="on_order" <?= $product['availability'] === 'on_order' ? 'selected' : '' ?>>يتوفر بالطلب</option>
            </select>
            <span style="font-size:12px;color:var(--color-text-muted)">إذا كانت الكمية أكبر من صفر تصبح "متوفر" تلقائيًا مهما اخترت هنا.</span>
        </div>
        <div class="form-group">
            <label style="display:flex;align-items:center;gap:8px;margin-top:26px">
                <input type="checkbox" name="is_featured" value="1" style="width:auto" <?= $product['is_featured'] ? 'checked' : '' ?>>
                منتج مميز (يظهر في الصفحة الرئيسية)
            </label>
        </div>
    </div>

    <div class="form-group">
        <label>السيارات المتوافقة (اختياري)</label>
        <input type="text" name="compatible_cars" value="<?= clean($product['compatible_cars']) ?>" placeholder="مثال: تويوتا كامري 2015-2019، كورولا 2016-2020">
    </div>

    <div class="form-group">
        <label>الوصف التفصيلي</label>
        <textarea name="description" rows="5"><?= clean($product['description']) ?></textarea>
    </div>

    <div class="form-grid">
        <div class="form-group">
            <label>الصورة الرئيسية <?= $isEdit ? '' : '<span class="req">*</span>' ?></label>
            <div class="image-upload-box">
                <img id="mainImagePreview" class="image-preview" src="<?= clean(product_thumb_url($product)) ?>" alt="">
                <input type="file" name="main_image" accept="image/png,image/jpeg,image/webp" data-image-input="mainImagePreview">
                <p style="font-size:12px;color:var(--color-text-muted);margin:8px 0 0">JPG أو PNG أو WEBP، حتى <?= MAX_UPLOAD_SIZE_MB ?> ميجابايت</p>
            </div>
        </div>
        <div class="form-group">
            <label>صور إضافية (يمكن اختيار أكثر من صورة)</label>
            <div class="image-upload-box">
                <input type="file" name="gallery_images[]" accept="image/png,image/jpeg,image/webp" multiple>
                <?php if (!empty($galleryImages)): ?>
                    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
                        <?php foreach ($galleryImages as $img): ?>
                            <div style="position:relative">
                                <img src="<?= clean(product_image_url($img['image_path'])) ?>" style="width:60px;height:60px;object-fit:contain;background:#fff;border:1px solid var(--color-border);border-radius:4px;padding:4px">
                                <form method="post" action="<?= base_url('admin/product_image_delete.php') ?>" style="position:absolute;top:-6px;left:-6px">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="image_id" value="<?= (int)$img['id'] ?>">
                                    <input type="hidden" name="product_id" value="<?= (int)$id ?>">
                                    <button type="submit" data-confirm="حذف هذه الصورة؟" style="width:20px;height:20px;border-radius:50%;background:var(--color-accent);color:#fff;border:none;font-size:11px;line-height:1">×</button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div style="display:flex;gap:10px;margin-top:20px">
        <button type="submit" class="btn btn-accent"><?= icon('check','icon-sm') ?> <?= $isEdit ? 'حفظ التعديلات' : 'إضافة المنتج' ?></button>
        <a href="<?= base_url('admin/products.php') ?>" class="btn btn-dark">إلغاء</a>
    </div>
</form>

<?php require __DIR__ . '/includes/admin_footer.php'; ?>
