<?php
require_once __DIR__ . '/includes/auth.php';
require_admin_login();

$pdo = get_db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();
    $action = $_POST['form_action'] ?? '';
    $id = (int)($_POST['id'] ?? 0);

    if ($action === 'delete') {
        $pdo->prepare('DELETE FROM contact_messages WHERE id = :id')->execute([':id' => $id]);
        flash_set('success', 'تم حذف الرسالة.');
    } elseif ($action === 'mark_read') {
        $pdo->prepare('UPDATE contact_messages SET is_read = 1 WHERE id = :id')->execute([':id' => $id]);
    }
    redirect(base_url('admin/messages.php'));
}

$messages = $pdo->query('SELECT * FROM contact_messages ORDER BY created_at DESC')->fetchAll();

$page_title = 'رسائل التواصل';
require __DIR__ . '/includes/admin_header.php';
?>

<div class="admin-table-wrap">
    <table class="admin-table">
        <thead><tr><th></th><th>الاسم</th><th>الهاتف</th><th>البريد</th><th>الرسالة</th><th>التاريخ</th><th></th></tr></thead>
        <tbody>
            <?php if (empty($messages)): ?>
                <tr><td colspan="7">لا توجد رسائل بعد.</td></tr>
            <?php endif; ?>
            <?php foreach ($messages as $m): ?>
            <tr style="<?= $m['is_read'] ? '' : 'background:var(--color-warning-bg)' ?>">
                <td><?= $m['is_read'] ? '' : '<span class="status-pill badge-warning">جديدة</span>' ?></td>
                <td><?= clean($m['name']) ?></td>
                <td dir="ltr"><?= clean($m['phone'] ?: '—') ?></td>
                <td><?= clean($m['email'] ?: '—') ?></td>
                <td style="max-width:320px;white-space:normal"><?= nl2br(clean($m['message'])) ?></td>
                <td><?= date('Y-m-d H:i', strtotime($m['created_at'])) ?></td>
                <td class="action-icons">
                    <?php if (!$m['is_read']): ?>
                    <form method="post" style="display:inline">
                        <?= csrf_field() ?>
                        <input type="hidden" name="form_action" value="mark_read">
                        <input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
                        <button type="submit" title="تمّت القراءة"><?= icon('check','icon-sm') ?></button>
                    </form>
                    <?php endif; ?>
                    <?php if ($m['phone']): ?>
                    <a href="<?= whatsapp_link('مرحبًا ' . $m['name']) ?>" target="_blank" rel="noopener" title="واتساب"><?= icon('whatsapp','icon-sm') ?></a>
                    <?php endif; ?>
                    <form method="post" style="display:inline">
                        <?= csrf_field() ?>
                        <input type="hidden" name="form_action" value="delete">
                        <input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
                        <button type="submit" class="danger" data-confirm="حذف هذه الرسالة؟"><?= icon('trash','icon-sm') ?></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php require __DIR__ . '/includes/admin_footer.php'; ?>
