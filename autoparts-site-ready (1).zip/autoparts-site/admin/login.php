<?php
require_once __DIR__ . '/includes/auth.php';

if (!admin_has_any_account()) {
    redirect(base_url('admin/setup.php'));
}

if (admin_logged_in()) {
    redirect(base_url('admin/index.php'));
}

$error = null;
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();
    $username = trim($_POST['username'] ?? '');
    $password = (string)($_POST['password'] ?? '');

    $result = attempt_admin_login($username, $password);
    if ($result['success']) {
        redirect(base_url('admin/index.php'));
    }
    $error = $result['message'];
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>تسجيل الدخول - لوحة التحكم | <?= clean(SITE_NAME) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600;700;800&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
<link rel="icon" href="<?= base_url('assets/images/logo/favicon-32.png') ?>" sizes="32x32">
<link rel="stylesheet" href="<?= base_url('admin/assets/admin.css') ?>">
<meta name="robots" content="noindex, nofollow">
</head>
<body class="admin-auth-body">
<div class="admin-auth-box">
    <div style="text-align:center;margin-bottom:20px">
        <img src="<?= logo_url() ?>" alt="<?= clean(SITE_NAME) ?>" class="brand-mark brand-mark-img" style="display:inline-flex">
    </div>
    <h1 class="font-display" style="font-size:20px;text-align:center">لوحة تحكم <?= clean(SITE_NAME) ?></h1>

    <?php if ($msg = flash_get('success')): ?>
        <div class="alert alert-success"><?= clean($msg) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= clean($error) ?></div>
    <?php endif; ?>

    <form method="post">
        <?= csrf_field() ?>
        <div class="form-group">
            <label>اسم المستخدم</label>
            <input type="text" name="username" required value="<?= clean($username) ?>" dir="ltr" autofocus>
        </div>
        <div class="form-group">
            <label>كلمة المرور</label>
            <input type="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-accent btn-block">تسجيل الدخول</button>
    </form>
</div>
</body>
</html>
