<?php
require_once __DIR__ . '/includes/auth.php';
require_admin_login();

$pdo = get_db();
$id = (int)($_GET['id'] ?? 0);
$validStatuses = ['new', 'processing', 'confirmed', 'shipped', 'completed', 'cancelled'];

$stmt = $pdo->prepare('SELECT * FROM orders WHERE id = :id');
$stmt->execute([':id' => $id]);
$order = $stmt->fetch();

if (!$order) {
    flash_set('error', 'الطلب غير موجود.');
    redirect(base_url('admin/orders.php'));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();
    $newStatus = $_POST['status'] ?? '';
    if (isset($_POST['mark_paid'])) {
        $pdo->prepare("UPDATE orders SET payment_status = 'paid' WHERE id = :id")->execute([':id' => $id]);
        flash_set('success', 'تم تعليم الطلب كمدفوع.');
        redirect(base_url('admin/order_view.php?id=' . $id));
    }

    if (in_array($newStatus, $validStatuses, true) && $newStatus !== $order['status']) {
        $pdo->beginTransaction();
        // عند الإلغاء: إعادة الكميات للمخزون تلقائيًا. عند التراجع عن الإلغاء: خصمها من جديد.
        if ($newStatus === 'cancelled' || $order['status'] === 'cancelled') {
            $sign = $newStatus === 'cancelled' ? 1 : -1;
            $itemsForStock = $pdo->prepare('SELECT product_id, quantity FROM order_items WHERE order_id = :id');
            $itemsForStock->execute([':id' => $id]);
            foreach ($itemsForStock->fetchAll() as $it) {
                if ($it['product_id']) {
                    apply_stock_delta($pdo, (int)$it['product_id'], $sign * (int)$it['quantity']);
                }
            }
        }
        $pdo->prepare('UPDATE orders SET status = :s WHERE id = :id')->execute([':s' => $newStatus, ':id' => $id]);
        $pdo->commit();
        flash_set('success', 'تم تحديث حالة الطلب بنجاح.' . ($newStatus === 'cancelled' ? ' وأُعيدت الكميات للمخزون.' : ''));
        redirect(base_url('admin/order_view.php?id=' . $id));
    } elseif (in_array($newStatus, $validStatuses, true)) {
        redirect(base_url('admin/order_view.php?id=' . $id));
    }
}

$itemsStmt = $pdo->prepare('SELECT * FROM order_items WHERE order_id = :id');
$itemsStmt->execute([':id' => $id]);
$items = $itemsStmt->fetchAll();

$page_title = 'تفاصيل الطلب ' . $order['order_number'];
require __DIR__ . '/includes/admin_header.php';
?>

<div class="toolbar">
    <a href="<?= base_url('admin/orders.php') ?>" class="btn btn-sm btn-dark">&#8594; العودة لكل الطلبات</a>
    <a href="<?= whatsapp_link('مرحبًا ' . $order['customer_name'] . '، بخصوص طلبك رقم ' . $order['order_number']) ?>" target="_blank" rel="noopener" class="btn btn-whatsapp btn-sm">
        <?= icon('whatsapp','icon-sm') ?> تواصل مع العميل عبر واتساب
    </a>
</div>

<div class="filters-layout layout-main-side">
    <div>
        <div class="card-box" style="margin-bottom:20px">
            <h3 style="font-size:16px;margin-bottom:14px">بيانات العميل</h3>
            <table class="spec-table">
                <tr><td>الاسم</td><td><?= clean($order['customer_name']) ?></td></tr>
                <tr><td>الهاتف</td><td dir="ltr"><?= clean($order['phone']) ?></td></tr>
                <tr><td>واتساب</td><td dir="ltr"><?= clean($order['whatsapp'] ?: '—') ?></td></tr>
                <tr><td>البريد الإلكتروني</td><td><?= clean($order['email'] ?: '—') ?></td></tr>
                <tr><td>المدينة</td><td><?= clean($order['city']) ?></td></tr>
                <tr><td>العنوان</td><td><?= clean($order['address'] ?: '—') ?></td></tr>
                <tr><td>ملاحظات العميل</td><td><?= nl2br(clean($order['notes'] ?: '—')) ?></td></tr>
                <tr><td>تاريخ الطلب</td><td><?= date('Y-m-d H:i', strtotime($order['created_at'])) ?></td></tr>
            </table>
        </div>

        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead><tr><th>المنتج</th><th>رقم القطعة</th><th>السعر</th><th>الكمية</th><th>الإجمالي</th></tr></thead>
                <tbody>
                    <?php foreach ($items as $item): ?>
                    <tr>
                        <td><?= clean($item['product_name']) ?></td>
                        <td dir="ltr"><?= clean($item['part_number']) ?></td>
                        <td><?= format_price((float)$item['price']) ?></td>
                        <td><?= (int)$item['quantity'] ?></td>
                        <td><?= format_price((float)$item['subtotal']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card-box" style="height:fit-content">
        <h3 style="font-size:16px">حالة الطلب</h3>
        <div class="summary-row"><span>قبل الضريبة</span><span><?= format_price((float)$order['subtotal_amount']) ?></span></div>
        <div class="summary-row"><span>الشحن</span><span><?= (float)$order['shipping_amount'] > 0 ? format_price((float)$order['shipping_amount']) : 'مجاني' ?></span></div>
        <div class="summary-row"><span>ضريبة القيمة المضافة</span><span><?= format_price((float)$order['vat_amount']) ?></span></div>
        <div class="summary-row total" style="padding-bottom:14px"><span>الإجمالي شامل الضريبة</span><span><?= format_price((float)$order['total_amount']) ?></span></div>

        <div class="summary-row">
            <span>طريقة الدفع</span>
            <span>
                <?= payment_method_label($order['payment_method']) ?>
                <?php if ($order['payment_method'] === 'bank_transfer'): ?>
                    <span class="status-pill <?= $order['payment_status'] === 'paid' ? 'badge-success' : 'badge-warning' ?>"><?= payment_status_label($order['payment_status']) ?></span>
                <?php endif; ?>
            </span>
        </div>

        <?php if ($order['payment_method'] === 'bank_transfer' && $order['payment_status'] !== 'paid'): ?>
        <form method="post" style="margin-bottom:14px">
            <?= csrf_field() ?>
            <button type="submit" name="mark_paid" value="1" class="btn btn-dark btn-block btn-sm"><?= icon('check','icon-sm') ?> تعليم كـ"تم استلام التحويل"</button>
        </form>
        <?php endif; ?>

        <form method="post">
            <?= csrf_field() ?>
            <div class="form-group">
                <label>الحالة الحالية</label>
                <select name="status">
                    <?php foreach ($validStatuses as $s): ?>
                        <option value="<?= $s ?>" <?= $order['status'] === $s ? 'selected' : '' ?>><?= order_status_label($s) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <p style="font-size:12px;color:var(--color-text-muted);margin:-6px 0 14px">اختيار «ملغي» يعيد كميات القطع للمخزون تلقائيًا.</p>
            <button type="submit" class="btn btn-accent btn-block"><?= icon('check','icon-sm') ?> تحديث الحالة</button>
        </form>
    </div>
</div>

<?php require __DIR__ . '/includes/admin_footer.php'; ?>
