<?php
require_once __DIR__ . '/includes/auth.php';
require_admin_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(base_url('admin/products.php'));
}
require_valid_csrf();

$id = (int)($_POST['id'] ?? 0);
$price = (float)($_POST['price'] ?? -1);
$stock = max(0, (int)($_POST['stock_quantity'] ?? 0));
$requestedAvailability = $_POST['availability'] ?? 'available';
if (!in_array($requestedAvailability, ['available', 'out_of_stock', 'on_order'], true)) {
    $requestedAvailability = 'available';
}
$return = $_POST['return'] ?? '/admin/products.php';
// السماح فقط برابط داخلي نسبي لصفحة المنتجات (مع الحفاظ على الفلاتر وترقيم الصفحات)، منعًا لإعادة توجيه مفتوحة
$allowedPath = parse_url(base_url('admin/products.php'), PHP_URL_PATH);
$returnPath = parse_url($return, PHP_URL_PATH);
if ($returnPath !== $allowedPath || str_contains($return, '://')) {
    $return = base_url('admin/products.php');
}

if ($id <= 0 || $price < 0) {
    flash_set('error', 'بيانات غير صالحة، لم يتم الحفظ.');
    redirect($return);
}

$availability = resolve_availability($stock, $requestedAvailability);

$pdo = get_db();
$stmt = $pdo->prepare('UPDATE products SET price = :price, stock_quantity = :stock, availability = :avail WHERE id = :id');
$stmt->execute([':price' => $price, ':stock' => $stock, ':avail' => $availability, ':id' => $id]);

flash_set('success', 'تم تحديث السعر والكمية بنجاح.');
redirect($return);
