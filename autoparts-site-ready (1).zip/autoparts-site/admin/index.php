<?php
require_once __DIR__ . '/includes/auth.php';
require_admin_login();

$pdo = get_db();
$productCount = (int)$pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$outOfStockCount = (int)$pdo->query("SELECT COUNT(*) FROM products WHERE stock_quantity = 0")->fetchColumn();
$lowStockCount = (int)$pdo->query('SELECT COUNT(*) FROM products WHERE stock_quantity > 0 AND stock_quantity <= ' . (int)LOW_STOCK_THRESHOLD)->fetchColumn();
$newOrdersCount = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'new'")->fetchColumn();
$totalOrdersCount = (int)$pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$unreadMessages = (int)$pdo->query("SELECT COUNT(*) FROM contact_messages WHERE is_read = 0")->fetchColumn();

$recentOrders = $pdo->query("SELECT * FROM orders ORDER BY created_at DESC LIMIT 8")->fetchAll();

$page_title = 'نظرة عامة';
require __DIR__ . '/includes/admin_header.php';
?>

<div class="stat-grid">
    <div class="stat-card"><b><?= $productCount ?></b><span>إجمالي المنتجات</span></div>
    <div class="stat-card"><b><?= $newOrdersCount ?></b><span>طلبات جديدة</span></div>
    <div class="stat-card"><b><?= $totalOrdersCount ?></b><span>إجمالي الطلبات</span></div>
    <a class="stat-card" style="display:block" href="<?= base_url('admin/products.php?stock=out') ?>"><b><?= $outOfStockCount ?></b><span>منتجات نفد مخزونها</span></a>
    <a class="stat-card" style="display:block" href="<?= base_url('admin/products.php?stock=low') ?>"><b><?= $lowStockCount ?></b><span>كمية منخفضة (≤ <?= LOW_STOCK_THRESHOLD ?>)</span></a>
    <div class="stat-card"><b><?= $unreadMessages ?></b><span>رسائل غير مقروءة</span></div>
</div>

<div class="toolbar">
    <h2 style="font-size:17px;margin:0">أحدث الطلبات</h2>
    <div style="display:flex;gap:8px">
        <a href="<?= base_url('admin/bulk_update.php') ?>" class="btn btn-sm" style="background:var(--color-bg)"><?= icon('edit','icon-sm') ?> تحديث الأسعار والمخزون</a>
        <a href="<?= base_url('admin/orders.php') ?>" class="btn btn-sm btn-dark">عرض كل الطلبات</a>
    </div>
</div>

<div class="admin-table-wrap">
    <table class="admin-table">
        <thead>
            <tr><th>رقم الطلب</th><th>العميل</th><th>الهاتف</th><th>الإجمالي</th><th>الحالة</th><th>التاريخ</th><th></th></tr>
        </thead>
        <tbody>
            <?php if (empty($recentOrders)): ?>
                <tr><td colspan="7">لا توجد طلبات بعد.</td></tr>
            <?php endif; ?>
            <?php foreach ($recentOrders as $o): ?>
            <tr>
                <td><?= clean($o['order_number']) ?></td>
                <td><?= clean($o['customer_name']) ?></td>
                <td dir="ltr"><?= clean($o['phone']) ?></td>
                <td><?= format_price((float)$o['total_amount']) ?></td>
                <td><span class="status-pill badge-<?= $o['status'] === 'new' ? 'warning' : ($o['status'] === 'cancelled' ? 'danger' : 'success') ?>"><?= order_status_label($o['status']) ?></span></td>
                <td><?= date('Y-m-d H:i', strtotime($o['created_at'])) ?></td>
                <td class="action-icons"><a href="<?= base_url('admin/order_view.php?id=' . (int)$o['id']) ?>"><?= icon('edit','icon-sm') ?></a></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php require __DIR__ . '/includes/admin_footer.php'; ?>
