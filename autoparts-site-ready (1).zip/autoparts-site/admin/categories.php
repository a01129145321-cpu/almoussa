<?php
require_once __DIR__ . '/includes/auth.php';
require_admin_login();

$pdo = get_db();
$errors = [];
$editing = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();
    $action = $_POST['form_action'] ?? '';

    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $pdo->prepare('DELETE FROM categories WHERE id = :id')->execute([':id' => $id]);
        flash_set('success', 'تم حذف القسم. المنتجات المرتبطة به أصبحت بدون قسم محدد.');
        redirect(base_url('admin/categories.php'));
    }

    $name = sanitize_text($_POST['name'] ?? '');
    $description = sanitize_text($_POST['description'] ?? '');
    $icon = sanitize_text($_POST['icon'] ?? 'box');
    $sortOrder = (int)($_POST['sort_order'] ?? 0);
    $id = (int)($_POST['id'] ?? 0);

    if ($name === '') $errors[] = 'الرجاء إدخال اسم القسم.';

    if (empty($errors)) {
        $slug = slugify($name);
        if ($id > 0) {
            $pdo->prepare('UPDATE categories SET name=:n, slug=:s, description=:d, icon=:i, sort_order=:so WHERE id=:id')
                ->execute([':n' => $name, ':s' => $slug, ':d' => $description, ':i' => $icon, ':so' => $sortOrder, ':id' => $id]);
            flash_set('success', 'تم تحديث القسم بنجاح.');
        } else {
            $pdo->prepare('INSERT INTO categories (name, slug, description, icon, sort_order) VALUES (:n,:s,:d,:i,:so)')
                ->execute([':n' => $name, ':s' => $slug, ':d' => $description, ':i' => $icon, ':so' => $sortOrder]);
            flash_set('success', 'تم إضافة القسم بنجاح.');
        }
        redirect(base_url('admin/categories.php'));
    }
}

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM categories WHERE id = :id');
    $stmt->execute([':id' => (int)$_GET['edit']]);
    $editing = $stmt->fetch();
}

$categories = $pdo->query("
    SELECT c.*, COUNT(p.id) AS product_count FROM categories c
    LEFT JOIN products p ON p.category_id = c.id
    GROUP BY c.id ORDER BY c.sort_order ASC
")->fetchAll();

$availableIcons = ['box', 'engine', 'brake', 'battery', 'tire', 'filter', 'suspension', 'wrench', 'truck', 'badge'];

$page_title = 'إدارة الأقسام';
require __DIR__ . '/includes/admin_header.php';
?>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger"><?php foreach ($errors as $e): ?><div><?= clean($e) ?></div><?php endforeach; ?></div>
<?php endif; ?>

<div class="filters-layout layout-main-side">
    <div class="admin-table-wrap">
        <table class="admin-table">
            <thead><tr><th>الاسم</th><th>عدد المنتجات</th><th>الترتيب</th><th></th></tr></thead>
            <tbody>
                <?php foreach ($categories as $c): ?>
                <tr>
                    <td><?= icon($c['icon'] ?: 'box', 'icon-sm') ?> <?= clean($c['name']) ?></td>
                    <td><?= (int)$c['product_count'] ?></td>
                    <td><?= (int)$c['sort_order'] ?></td>
                    <td class="action-icons">
                        <a href="<?= base_url('admin/categories.php?edit=' . (int)$c['id']) ?>"><?= icon('edit','icon-sm') ?></a>
                        <form method="post" style="display:inline">
                            <?= csrf_field() ?>
                            <input type="hidden" name="form_action" value="delete">
                            <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                            <button type="submit" class="danger" data-confirm="حذف هذا القسم؟ ستبقى المنتجات لكن بدون قسم محدد."><?= icon('trash','icon-sm') ?></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="card-box">
        <h3 style="font-size:16px"><?= $editing ? 'تعديل القسم' : 'إضافة قسم جديد' ?></h3>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= $editing['id'] ?? '' ?>">
            <div class="form-group">
                <label>اسم القسم <span class="req">*</span></label>
                <input type="text" name="name" required value="<?= clean($editing['name'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>وصف مختصر</label>
                <input type="text" name="description" value="<?= clean($editing['description'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>الأيقونة</label>
                <select name="icon">
                    <?php foreach ($availableIcons as $ic): ?>
                        <option value="<?= $ic ?>" <?= ($editing['icon'] ?? '') === $ic ? 'selected' : '' ?>><?= $ic ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>ترتيب الظهور</label>
                <input type="number" name="sort_order" value="<?= clean((string)($editing['sort_order'] ?? 0)) ?>">
            </div>
            <button type="submit" class="btn btn-accent btn-block"><?= $editing ? 'حفظ التعديلات' : 'إضافة' ?></button>
            <?php if ($editing): ?><a href="<?= base_url('admin/categories.php') ?>" class="btn btn-dark btn-block" style="margin-top:8px">إلغاء</a><?php endif; ?>
        </form>
    </div>
</div>

<?php require __DIR__ . '/includes/admin_footer.php'; ?>
