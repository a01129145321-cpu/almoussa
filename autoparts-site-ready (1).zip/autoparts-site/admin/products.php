<?php
require_once __DIR__ . '/includes/auth.php';
require_admin_login();

$pdo = get_db();

$search        = trim($_GET['q'] ?? '');
$categoryId    = (int)($_GET['category'] ?? 0);
$manufacturerId = (int)($_GET['manufacturer'] ?? 0);
$stockFilter   = $_GET['stock'] ?? '';
$sort          = $_GET['sort'] ?? 'new';
$page          = max(1, (int)($_GET['page'] ?? 1));
$perPage       = 50;

$where = ['1=1'];
$params = [];

if ($search !== '') {
    $where[] = product_search_sql($search, $params);
}
if ($categoryId > 0) { $where[] = 'p.category_id = :cat'; $params[':cat'] = $categoryId; }
if ($manufacturerId > 0) { $where[] = 'p.manufacturer_id = :man'; $params[':man'] = $manufacturerId; }

switch ($stockFilter) {
    case 'out':       $where[] = 'p.stock_quantity = 0'; break;
    case 'low':       $where[] = 'p.stock_quantity > 0 AND p.stock_quantity <= ' . (int)LOW_STOCK_THRESHOLD; break;
    case 'available': $where[] = 'p.stock_quantity > ' . (int)LOW_STOCK_THRESHOLD; break;
}

$orderSql = match ($sort) {
    'price_asc'  => 'p.price ASC, p.id ASC',
    'price_desc' => 'p.price DESC, p.id ASC',
    'qty_asc'    => 'p.stock_quantity ASC, p.id ASC',
    'qty_desc'   => 'p.stock_quantity DESC, p.id ASC',
    'name'       => 'p.name ASC, p.id ASC',
    default      => 'p.id DESC',
};

$whereSql = implode(' AND ', $where);

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM products p WHERE $whereSql");
$countStmt->execute($params);
$totalItems = (int)$countStmt->fetchColumn();
$totalPages = max(1, (int)ceil($totalItems / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

$stmt = $pdo->prepare("
    SELECT p.*, c.name AS category_name, m.name AS manufacturer_name
    FROM products p
    LEFT JOIN categories c ON c.id = p.category_id
    LEFT JOIN manufacturers m ON m.id = p.manufacturer_id
    WHERE $whereSql
    ORDER BY $orderSql
    LIMIT :limit OFFSET :offset
");
foreach ($params as $k => $v) { $stmt->bindValue($k, $v); }
$stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$products = $stmt->fetchAll();

$categories = $pdo->query('SELECT * FROM categories ORDER BY name ASC')->fetchAll();
$manufacturers = $pdo->query('SELECT * FROM manufacturers ORDER BY name ASC')->fetchAll();

$outCount = (int)$pdo->query('SELECT COUNT(*) FROM products WHERE stock_quantity = 0')->fetchColumn();
$lowCount = (int)$pdo->query('SELECT COUNT(*) FROM products WHERE stock_quantity > 0 AND stock_quantity <= ' . (int)LOW_STOCK_THRESHOLD)->fetchColumn();

function qbuild(array $override = []): string
{
    $cur = $_GET;
    foreach ($override as $k => $v) {
        if ($v === null) { unset($cur[$k]); } else { $cur[$k] = $v; }
    }
    return '?' . http_build_query($cur);
}

$page_title = 'إدارة المنتجات';
require __DIR__ . '/includes/admin_header.php';
?>

<div class="toolbar">
    <form method="get" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
        <input type="text" name="q" value="<?= clean($search) ?>" placeholder="ابحث بالاسم أو رقم القطعة...">
        <select name="category" onchange="this.form.submit()">
            <option value="0">كل الأقسام</option>
            <?php foreach ($categories as $c): ?>
                <option value="<?= $c['id'] ?>" <?= $categoryId === (int)$c['id'] ? 'selected' : '' ?>><?= clean($c['name']) ?></option>
            <?php endforeach; ?>
        </select>
        <select name="manufacturer" onchange="this.form.submit()">
            <option value="0">كل الشركات</option>
            <?php foreach ($manufacturers as $m): ?>
                <option value="<?= $m['id'] ?>" <?= $manufacturerId === (int)$m['id'] ? 'selected' : '' ?>><?= clean($m['name']) ?></option>
            <?php endforeach; ?>
        </select>
        <select name="stock" onchange="this.form.submit()">
            <option value="">كل حالات المخزون</option>
            <option value="out" <?= $stockFilter === 'out' ? 'selected' : '' ?>>نفد المخزون (<?= $outCount ?>)</option>
            <option value="low" <?= $stockFilter === 'low' ? 'selected' : '' ?>>كمية منخفضة ≤ <?= LOW_STOCK_THRESHOLD ?> (<?= $lowCount ?>)</option>
            <option value="available" <?= $stockFilter === 'available' ? 'selected' : '' ?>>متوفر بكمية جيدة</option>
        </select>
        <select name="sort" onchange="this.form.submit()">
            <option value="new" <?= $sort === 'new' ? 'selected' : '' ?>>الأحدث</option>
            <option value="qty_asc" <?= $sort === 'qty_asc' ? 'selected' : '' ?>>الكمية: الأقل أولًا</option>
            <option value="qty_desc" <?= $sort === 'qty_desc' ? 'selected' : '' ?>>الكمية: الأكثر أولًا</option>
            <option value="price_asc" <?= $sort === 'price_asc' ? 'selected' : '' ?>>السعر: الأقل أولًا</option>
            <option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>>السعر: الأعلى أولًا</option>
            <option value="name" <?= $sort === 'name' ? 'selected' : '' ?>>الاسم أبجديًا</option>
        </select>
        <button class="btn btn-dark btn-sm" type="submit"><?= icon('search','icon-sm') ?> تصفية</button>
        <?php if ($search || $categoryId || $manufacturerId || $stockFilter || $sort !== 'new'): ?>
            <a href="<?= base_url('admin/products.php') ?>" class="btn btn-sm" style="background:var(--color-bg)">إلغاء التصفية</a>
        <?php endif; ?>
    </form>
    <a href="<?= base_url('admin/product_form.php') ?>" class="btn btn-accent"><?= icon('plus','icon-sm') ?> إضافة منتج جديد</a>
</div>

<p style="color:var(--color-text-muted);font-size:14px;margin:-8px 0 16px">
    عرض <?= count($products) ?> من أصل <?= $totalItems ?> منتجًا (صفحة <?= $page ?> من <?= $totalPages ?>)
    — غيّر السعر أو الكمية مباشرة في الجدول ثم اضغط «حفظ».
</p>

<div class="admin-table-wrap">
    <table class="admin-table">
        <thead>
            <tr><th>الصورة</th><th>الاسم</th><th>رقم القطعة</th><th>القسم</th><th colspan="3">السعر / الكمية / التوفر</th><th></th></tr>
        </thead>
        <tbody>
            <?php if (empty($products)): ?>
                <tr><td colspan="8">لا توجد منتجات مطابقة.</td></tr>
            <?php endif; ?>
            <?php foreach ($products as $p): ?>
            <tr>
                <td><img class="thumb" src="<?= clean(product_thumb_url($p)) ?>" alt=""></td>
                <td>
                    <?= clean($p['name']) ?>
                    <div style="font-size:12px;color:var(--color-text-muted)"><?= clean($p['manufacturer_name'] ?: '—') ?></div>
                </td>
                <td dir="ltr"><?= clean($p['part_number']) ?></td>
                <td><?= clean($p['category_name'] ?: '—') ?></td>
                <td colspan="3">
                    <form method="post" action="<?= base_url('admin/product_quick_update.php') ?>" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                        <input type="hidden" name="return" value="<?= clean($_SERVER['REQUEST_URI']) ?>">
                        <span style="display:flex;align-items:center;gap:4px">
                            <input type="number" step="0.01" min="0" name="price" value="<?= clean((string)$p['price']) ?>" style="width:90px" required>
                            <span style="font-size:12px;color:var(--color-text-muted)"><?= CURRENCY ?></span>
                        </span>
                        <span style="display:flex;align-items:center;gap:4px">
                            <input type="number" min="0" name="stock_quantity" value="<?= (int)$p['stock_quantity'] ?>" style="width:75px" required>
                            <span style="font-size:12px;color:var(--color-text-muted)">قطعة</span>
                        </span>
                        <select name="availability" style="width:auto">
                            <option value="available" <?= $p['availability'] === 'available' ? 'selected' : '' ?>>متوفر</option>
                            <option value="out_of_stock" <?= $p['availability'] === 'out_of_stock' ? 'selected' : '' ?>>غير متوفر</option>
                            <option value="on_order" <?= $p['availability'] === 'on_order' ? 'selected' : '' ?>>يتوفر بالطلب</option>
                        </select>
                        <button type="submit" class="btn btn-sm btn-dark">حفظ</button>
                    </form>
                </td>
                <td class="action-icons">
                    <a href="<?= base_url('product.php?id=' . (int)$p['id']) ?>" target="_blank" title="معاينة"><?= icon('search','icon-sm') ?></a>
                    <a href="<?= base_url('admin/product_form.php?id=' . (int)$p['id']) ?>" title="تعديل كامل"><?= icon('edit','icon-sm') ?></a>
                    <form method="post" action="<?= base_url('admin/product_delete.php') ?>" style="display:inline">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                        <button type="submit" class="danger" data-confirm="هل تريد حذف هذا المنتج نهائيًا؟" title="حذف"><?= icon('trash','icon-sm') ?></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php if ($totalPages > 1): ?>
<div class="pagination">
    <?php if ($page > 1): ?><a href="<?= qbuild(['page' => $page - 1]) ?>">السابق</a><?php endif; ?>
    <?php
    $start = max(1, $page - 3); $end = min($totalPages, $page + 3);
    if ($start > 1) echo '<a href="' . qbuild(['page' => 1]) . '">1</a><span>…</span>';
    for ($i = $start; $i <= $end; $i++):
        if ($i === $page): ?><span class="active"><?= $i ?></span><?php else: ?><a href="<?= qbuild(['page' => $i]) ?>"><?= $i ?></a><?php endif;
    endfor;
    if ($end < $totalPages) echo '<span>…</span><a href="' . qbuild(['page' => $totalPages]) . '">' . $totalPages . '</a>';
    ?>
    <?php if ($page < $totalPages): ?><a href="<?= qbuild(['page' => $page + 1]) ?>">التالي</a><?php endif; ?>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/admin_footer.php'; ?>
