<?php
require_once __DIR__ . '/includes/auth.php';
require_admin_login();

$pdo = get_db();
$report = [];
$destDir = __DIR__ . '/../uploads/parts/';
$allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();

    if (!is_dir($destDir)) {
        mkdir($destDir, 0755, true);
    }

    $files = $_FILES['images'] ?? null;
    $count = $files ? count($files['name']) : 0;

    for ($i = 0; $i < $count; $i++) {
        $orig = $files['name'][$i];
        if ($orig === '' || $files['error'][$i] === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        $part = pathinfo($orig, PATHINFO_FILENAME);

        if ($files['error'][$i] !== UPLOAD_ERR_OK) {
            $report[] = ['ok' => false, 'name' => $orig, 'msg' => 'فشل الرفع'];
            continue;
        }
        if (!preg_match('/^[A-Za-z0-9\-_.]+$/', $part)) {
            $report[] = ['ok' => false, 'name' => $orig, 'msg' => 'اسم الملف يجب أن يكون رقم القطعة فقط (حروف/أرقام/شرطة)'];
            continue;
        }
        if ($files['size'][$i] > MAX_UPLOAD_SIZE_MB * 1024 * 1024) {
            $report[] = ['ok' => false, 'name' => $orig, 'msg' => 'حجم الصورة كبير'];
            continue;
        }

        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($files['tmp_name'][$i]);
        if (!isset($allowed[$mime]) || @getimagesize($files['tmp_name'][$i]) === false) {
            $report[] = ['ok' => false, 'name' => $orig, 'msg' => 'الملف ليس صورة JPG/PNG/WEBP صالحة'];
            continue;
        }

        $chk = $pdo->prepare('SELECT COUNT(*) FROM products WHERE part_number = :p');
        $chk->execute([':p' => $part]);
        if ((int)$chk->fetchColumn() === 0) {
            $report[] = ['ok' => false, 'name' => $orig, 'msg' => 'لا يوجد منتج بهذا الرقم'];
            continue;
        }

        // حذف أي نسخة قديمة بامتداد آخر ثم حفظ الجديدة
        foreach (['jpg', 'jpeg', 'png', 'webp'] as $ext) {
            @unlink($destDir . $part . '.' . $ext);
        }
        if (move_uploaded_file($files['tmp_name'][$i], $destDir . $part . '.' . $allowed[$mime])) {
            $report[] = ['ok' => true, 'name' => $orig, 'msg' => 'تم ربط الصورة بالقطعة ' . $part];
        } else {
            $report[] = ['ok' => false, 'name' => $orig, 'msg' => 'تعذر حفظ الملف'];
        }
    }
}

$withImage = 0;
foreach (glob($destDir . '*.{jpg,jpeg,png,webp}', GLOB_BRACE) ?: [] as $f) {
    $withImage++;
}
$total = (int)$pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();

$page_title = 'رفع صور القطع برقم القطعة';
require __DIR__ . '/includes/admin_header.php';
?>

<div class="card-box" style="max-width:820px;margin-bottom:20px">
    <p style="margin:0 0 8px"><b>صور مرتبطة حاليًا:</b> <?= $withImage ?> من <?= $total ?> منتج</p>
    <p style="color:var(--color-text-muted);margin:0;font-size:14px">
        سمِّ كل صورة برقم القطعة تمامًا، مثال: <span dir="ltr" class="part-tag">90919-02154.jpg</span>
        ثم ارفعها هنا (حتى 20 صورة في المرة الواحدة حسب إعدادات PHP). للأعداد الكبيرة ارفع الصور مباشرة
        إلى مجلد <code>uploads/parts/</code> عبر مدير الملفات في Hostinger بنفس التسمية، وستظهر تلقائيًا.
    </p>
</div>

<?php if (!empty($report)): ?>
<div class="admin-table-wrap" style="max-width:820px;margin-bottom:20px">
    <table class="admin-table">
        <thead><tr><th>الملف</th><th>النتيجة</th></tr></thead>
        <tbody>
        <?php foreach ($report as $r): ?>
            <tr><td dir="ltr"><?= clean($r['name']) ?></td>
                <td><span class="status-pill <?= $r['ok'] ? 'badge-success' : 'badge-danger' ?>"><?= clean($r['msg']) ?></span></td></tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data" class="card-box" style="max-width:820px">
    <?= csrf_field() ?>
    <div class="form-group">
        <label>اختر الصور (اسم الملف = رقم القطعة)</label>
        <input type="file" name="images[]" accept="image/png,image/jpeg,image/webp" multiple required>
    </div>
    <button type="submit" class="btn btn-accent"><?= icon('check','icon-sm') ?> رفع وربط الصور</button>
</form>

<?php require __DIR__ . '/includes/admin_footer.php'; ?>
